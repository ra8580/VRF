const targetEl = document.querySelector('#vrf-sidebar-container');

function loadSidebar() {
    fetch(`./sidebar.html`)
    .then(res => {
        if(res.ok) {
            return res.text();
        }
    })
    .then(htmlSnippet => {
        targetEl.innerHTML = htmlSnippet;
        
        var link = document.URL;
        var divided_link = link.split("/");
        var html_name = divided_link[(divided_link.length - 1)].split("/");
        var name = html_name[0];
        var sub_html_name = html_name[0].split(".");
        var sub_html_name = sub_html_name[0].split("-");
        var parent_link = sub_html_name[0];
        var active_parent_link = document.querySelector(`#${parent_link}-submenu`);
        var child_link = document.querySelector(`a[href="${name}"]`);

        if(active_parent_link !== null) {
            active_parent_link.classList.add('show');

            // for child-parent submenu
            if(child_link.parentElement) {
                child_link.parentElement.classList.add('show');
                child_link.classList.remove('text-white');
                child_link.classList.add('text-dark');
            } else {
                child_link.classList.remove('text-white');
                child_link.classList.add('text-dark');
            }

            // for child
            child_link.classList.remove('bg-dark');
            child_link.classList.add('bg-light');
            child_link.classList.add('fw-bold');
            
        }
    });
};

function copyText() {
    let btnCopys = document.querySelectorAll('.btn-clipboard');

    btnCopys.forEach( copy => {
        copy.addEventListener('click', function() {

            let id = this.parentElement.nextElementSibling.querySelector('pre code').getAttribute("id")
            let el = document.querySelector(`#${id}`);
            let range = document.createRange();
            range.selectNodeContents(el);
            let sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
            document.execCommand('copy');
        
        });
    });
}

loadSidebar();
copyText();