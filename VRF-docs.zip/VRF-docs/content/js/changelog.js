const Data = [
    {
        "ID" : 1,
        "Date": "7/23/2023",
        "Changeset": "3496039",
        "File": ["$/Markups/VRF/VRF-docs/index.html",
                "$/Markups/VRF/VRF-docs/sidebar.html", 
                "$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/content/js/docs.js"
                ],
        "Comment": "JJF - INTEGRATE - Added index/sidebar/virgin logo img"
    },
    {
        "ID" : 2,
        "Date": "7/23/2023",
        "Changeset": "3496064",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/brand-font.html", 
                "$/Markups/VRF/VRF-docs/virgin/brand-style-guide.html",
                "$/Markups/VRF/VRF-docs/virgin/brand-typography.html",
                "$/Markups/VRF/VRF-docs/virgin/index.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "JJF - INTEGRATE - Added font/typography/style-guide page"
    },
    {
        "ID" : 3,
        "Date": "7/24/2023",
        "Changeset": "3496541",
        "File": ["$/Markups/VRF/VRF-docs/html/asset-icons.html",
                "$/Markups/VRF/VRF-docs/html/logo.html"
                ],
        "Comment": "LR - INTEGRATE - Added virgin logo page"
    },
    {
        "ID" : 4,
        "Date": "7/24/2023",
        "Changeset": "3496855",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
                ],
        "Comment": "BFS - IGNORE - readded virgin utilities css"
    },
    {
        "ID" : 5,
        "Date": "7/24/2023",
        "Changeset": "3496949",
        "File": ["$/Markups/VRF/VRF-docs/content/js/docs.js",
                "$/Markups/VRF/VRF-docs/content/js/sidebar.js",
                "$/Markups/VRF/VRF-docs/virgin/index.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "JJF - INTEGRATE - Update sidebar function"
    },
    {
        "ID" : 6,
        "Date": "7/24/2023",
        "Changeset": "3497240",
        "File": ["$/Markups/VRF/VRF-docs/virgin/brand-font.html",
                "$/Markups/VRF/VRF-docs/virgin/brand-style-guide.html",
                "$/Markups/VRF/VRF-docs/virgin/brand-typography.html",
                "$/Markups/VRF/VRF-docs/virgin/index.html"
                ],
        "Comment": "JJF - INTEGRATE - Add vrf-utilities.css"
    },
    {
        "ID" : 7,
        "Date": "7/24/2023",
        "Changeset": "3497454",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/allBrowser_framework.css",
                "$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/Dev/PSSP/core/css/vrf-icons.css",
                "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/Dev/PSSP/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/core/css/bootstrap.css",
                "$/Markups/VRF/VRF-docs/core/css/bootstrap.css.map",
                "$/Markups/VRF/VRF-docs/core/css/bootstrap.min.css.map",
                "$/Markups/VRF/VRF-docs/core/js/bootstrap.bundle.js",
                "$/Markups/VRF/VRF-docs/core/js/bootstrap.bundle.js.map",
                "$/Markups/VRF/VRF-docs/core/js/bootstrap.bundle.min.js",
                "$/Markups/VRF/VRF-docs/core/js/bootstrap.bundle.min.js.map"
                ],
        "Comment": "BFS - IGNORE - transfer and overrides files from Core dev pssp and trasnfer files from core vrf docs"
    },
    {
        "ID" : 8,
        "Date": "7/24/2023",
        "Changeset": "3497479",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/global-nav.css",
                "$/Markups/VRF/VRF-docs/core/css/global-nav.css"
                ],
        "Comment": "BFS - IGNORE - Rename global nav css"
    },
    {
        "ID" : 9,
        "Date": "7/24/2023",
        "Changeset": "3497812",
        "File": ["$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/html/grids.html"
                ],
        "Comment": "DS - INTEGRATE - Added grids page"
    },
    {
        "ID" : 10,
        "Date": "7/24/2023",
        "Changeset": "3497821",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/html/effect-style.html"
                ],
        "Comment": "DS - INTEGRATE - Added effect style page"
    },
    {
        "ID" : 11,
        "Date": "7/24/2023",
        "Changeset": "3498050",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf-icons.css"
                ],
        "Comment": "BFS - IGNORE - Remove old icons and updated vrf icons .css"
    },
    {
        "ID" : 12,
        "Date": "7/24/2023",
        "Changeset": "3498054",
        "File": ["$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - IGNORE - Added updated icon files"
    },
    {
        "ID" : 13,
        "Date": "7/24/2023",
        "Changeset": "3498114",
        "File": ["$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "JJF - INTEGRATE - Add brand-color.html"
    },
    {
        "ID" : 14,
        "Date": "7/24/2023",
        "Changeset": "3498464",
        "File": ["$/Markups/VRF/VRF-docs/virgin/brand-colors.html"
                ],
        "Comment": "JJF - INTEGRATE - Add brand-color.html"
    },
    {
        "ID" : 15,
        "Date": "7/24/2023",
        "Changeset": "3498827",
        "File": ["$/Markups/VRF/VRF-docs/html/logo.html",
                "$/Markups/VRF/VRF-docs/virgin/brand-logo.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "LR - INTEGRATE - Added brand-logo page"
    },
    {
        "ID" : 16,
        "Date": "7/24/2023",
        "Changeset": "3498827",
        "File": ["$/Markups/VRF/VRF-docs/virgin/assets-buttons.html"
                ],
        "Comment": "JJF - INTEGRATE - Add assets-buttons.html"
    },
    {
        "ID" : 17,
        "Date": "7/24/2023",
        "Changeset": "3498889",
        "File": ["$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "JJF - IGNORE- fixed re-add brand-style-guide.html path"
    },
    {
        "ID" : 18,
        "Date": "7/24/2023",
        "Changeset": "3498896",
        "File": ["$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/html/grids.html"
                ],
        "Comment": "DS - IGNORE - update on class names for grids html"
    },
    {
        "ID" : 19,
        "Date": "7/24/2023",
        "Changeset": "3498925",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/html/links.html"
                ],
        "Comment": "DS - INTEGRATE - added sections for links html"
    },
    {
        "ID" : 20,
        "Date": "7/24/2023",
        "Changeset": "3499040",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "BFS - INTEGRATE - Retain yung columns no padding and breakpoint margins"
    },
    {
        "ID" : 21,
        "Date": "7/24/2023",
        "Changeset": "3499095",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "BFS - INTEGRATE -  added paddding utilities for core multiples of 8"
    },
    {
        "ID" : 22,
        "Date": "7/25/2023",
        "Changeset": "3499689",
        "File": ["$/Markups/VRF/VRF-docs/content/js/docs.js"
                ],
        "Comment": "JJF - INTEGRATE - Fixed sidebar function"
    },
    {
        "ID" : 23,
        "Date": "7/25/2023",
        "Changeset": "3499689",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf-icons.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css"
                ],
        "Comment": "DS - INTEGRATE - updated vrf-icons for docs an pssp core"
    },
    {
        "ID" : 24,
        "Date": "7/25/2023",
        "Changeset": "3499811",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/html/links.html"
                ],
        "Comment": "DS - INTEGRATE - link html completion"
    },
    {
        "ID" : 25,
        "Date": "7/25/2023",
        "Changeset": "3500202",
        "File": ["$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-links.html",
                "$/Markups/VRF/VRF-docs/virgin/brand-effect-style.html",
                "$/Markups/VRF/VRF-docs/virgin/brf-grids.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "DS - INTEGRATE - added links, effect-style,grids in vrf-docs-virgin, updated sidebar for new pages"
    },
    {
        "ID" : 26,
        "Date": "7/25/2023",
        "Changeset": "3500217",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf-icons.css"
                ],
        "Comment": "BFS - IGNORE - Deleted old icon files"
    },
    {
        "ID" : 27,
        "Date": "7/25/2023",
        "Changeset": "3500269",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf-icons.css",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - INTEGRATE - added new icon files and udpated icon css style"
    },
    {
        "ID" : 28,
        "Date": "7/25/2023",
        "Changeset": "3500281",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf-icons.css"
                ],
        "Comment": "BFS - IGNORE - remvoed old icon fiels and updated css style icons"
    },
    {
        "ID" : 29,
        "Date": "7/25/2023",
        "Changeset": "3500298",
        "File": ["$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - IGNORE - Readded icon files PSSP core and vrf docs core"
    },
    {
        "ID" : 30,
        "Date": "7/25/2023",
        "Changeset": "3500298",
        "File": ["$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - IGNORE - remvoed old icon fiels and updated css style icons"
    },
    {
        "ID" : 31,
        "Date": "7/25/2023",
        "Changeset": "3500349",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/virgin/assets-tooltips.html"
                ],
        "Comment": "KM - INTEGRATE - Added assets-tooltips.html"
    },
    {
        "ID" : 32,
        "Date": "7/25/2023",
        "Changeset": "3500417",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "DS - INTEGRATE - update on icon spacing for links"
    },
    {
        "ID" : 33,
        "Date": "7/25/2023",
        "Changeset": "3500429",
        "File": ["$/Markups/VRF/VRF-docs/html/links.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-links.html"
                ],
        "Comment": "DS - IGNORE - html update for links icons"
    },
    {
        "ID" : 34,
        "Date": "7/25/2023",
        "Changeset": "3500558",
        "File": ["$/Markups/VRF/VRF-docs/content/js/docs.js",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-input-fields.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "LR - INTEGRATE - Added Input fields"
    },
    {
        "ID" : 35,
        "Date": "7/25/2023",
        "Changeset": "3500562",
        "File": ["$/Markups/VRF/VRF-docs/core/js/vrf.js"
                ],
        "Comment": "KM - IGNORE - readded and refactor initial code in vrf.js"
    },
    {
        "ID" : 36,
        "Date": "7/25/2023",
        "Changeset": "3500654",
        "File": ["$/Markups/VRF/VRF-docs/virgin/assets-input-fields.html"
                ],
        "Comment": "LR - INTEGRATE - Update title of the page"
    },
    {
        "ID" : 37,
        "Date": "7/25/2023",
        "Changeset": "3500683",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/virgin/assets-modals.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "JJF - INTEGRATE - Add assets-modals.html"
    },
    {
        "ID" : 38,
        "Date": "7/25/2023",
        "Changeset": "3500817",
        "File": ["$/Markups/VRF/VRF-docs/virgin/accessibility-deque-notes.html",
                "$/Markups/VRF/VRF-docs/virgin/accessibility-resources.html",
                "$/Markups/VRF/VRF-docs/virgin/accessibility-tools.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "BFS - INTEGRATE - Added accessibility links in the sidenav bar"
    },
    {
        "ID" : 39,
        "Date": "7/25/2023",
        "Changeset": "3500931",
        "File": ["$/Markups/VRF/VRF-docs/virgin/accessibility-deque-notes.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "JJF - INTEGRATE - Update Web Accessibility 2.2 path"
    },
    {
        "ID" : 40,
        "Date": "7/25/2023",
        "Changeset": "3500987",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
                ],
        "Comment": "BFS - INTERGRATE - VRF utilitiy classes additional"
    },
    {
        "ID" : 41,
        "Date": "7/25/2023",
        "Changeset": "3501079",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "KM - INTEGRATE - Fixed btn-primary active bg color"
    },
    {
        "ID" : 42,
        "Date": "7/25/2023",
        "Changeset": "3501348",
        "File": ["$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "BFS - IGNORE - Changed the text in side nav guidelines from BRF to VRF"
    },
    {
        "ID" : 43,
        "Date": "7/25/2023",
        "Changeset": "3501554",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "KM - IGNORE - Fixed vrf.css version"
    },
    {
        "ID" : 44,
        "Date": "7/25/2023",
        "Changeset": "3501668",
        "File": ["$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/virgin/brf-supported-browsers.html"
                ],
        "Comment": "CD - INTEGRATE - Add Supported Browsers"
    },
    {
        "ID" : 45,
        "Date": "7/25/2023",
        "Changeset": "3501711",
        "File": ["$/Markups/VRF/VRF-docs/virgin/assets-tooltips.html"
                ],
        "Comment": "KM - INTEGRATE - Applied tooltip modal in asset tooltip"
    },
    {
        "ID" : 46,
        "Date": "7/25/2023",
        "Changeset": "3502391",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf-icons.css",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - INTERGATE - updated css icon styles"
    },
    {
        "ID" : 47,
        "Date": "7/25/2023",
        "Changeset": "3502392",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
                ],
        "Comment": "DS - INTEGRATE - update core css for text tags"
    },
    {
        "ID" : 48,
        "Date": "7/25/2023",
        "Changeset": "3502421",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
                ],
        "Comment": "DS - INTEGRATE - update core css for text tags"
    },
    {
        "ID" : 49,
        "Date": "7/25/2023",
        "Changeset": "3502441",
        "File": ["$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - INTEGRATE - Added new icon files"
    },
    {
        "ID" : 50,
        "Date": "7/25/2023",
        "Changeset": "3502699",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
                ],
        "Comment": "BFS - INTEGRATE - aligned utility classes in docs and pssp core"
    },
    {
        "ID" : 51,
        "Date": "7/25/2023",
        "Changeset": "3502708",
        "File": ["$/Markups/VRF/VRF-docs/virgin/brf-tools-design.html"
                ],
        "Comment": "CD - INTEGRATE - Add Design and Development Tools"
    },
    {
        "ID" : 52,
        "Date": "7/25/2023",
        "Changeset": "3502708",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "BFS - INTEGRATE - Aligned vrf css in both docs and pssp dev"
    },
    {
        "ID" : 53,
        "Date": "7/25/2023",
        "Changeset": "3502834",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "BFS - INTEGRATE - Aligned vrf css in both docs and pssp dev"
    },
    {
        "ID" : 54,
        "Date": "7/25/2023",
        "Changeset": "3503142",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-alerts.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "JJF - INTEGRATE - Add assets-alerts.html"
    },
    {
        "ID" : 55,
        "Date": "7/26/2023",
        "Changeset": "3503594",
        "File": ["$/Markups/VRF/VRF-docs/content/js/docs.js",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/html/input-fields.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-input-fields.html"
                ],
        "Comment": "LR - INTEGRATE - Update Input fields and transfer docs.js to vrf.js"
    },
    {
        "ID" : 56,
        "Date": "7/26/2023",
        "Changeset": "3503773",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-input-fields.html"
                ],
        "Comment": "KM - INTEGRATE - Added Input search field"
    },
    {
        "ID" : 57,
        "Date": "7/26/2023",
        "Changeset": "3503786",
        "File": ["$/Markups/VRF/VRF-docs/virgin/brand-colors.html"
                ],
        "Comment": "BFS - INTEGRATE - added comments in bg color docs from figma"
    },
    {
        "ID" : 58,
        "Date": "7/26/2023",
        "Changeset": "3503788",
        "File": ["$/Markups/VRF/VRF-docs/virgin/assets-alerts.html"
                ],
        "Comment": "JJF - INTEGRATE - Fix assets-alerts.html"
    },
    {
        "ID" : 59,
        "Date": "7/26/2023",
        "Changeset": "3504088",
        "File": ["$/Markups/VRF/VRF-docs/virgin/assets-alerts.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "DS - INTEGRATE - added assets-tags.html"
    },
    {
        "ID" : 60,
        "Date": "7/26/2023",
        "Changeset": "3504089",
        "File": ["$/Markups/VRF/VRF-docs/virgin/assets-alerts.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "DS - INTEGRATE - added assets-tags.html"
    },
    {
        "ID" : 61,
        "Date": "7/26/2023",
        "Changeset": "3505628",
        "File": ["$/Markups/VRF/Dev/PSSP/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js"
                ],
        "Comment": "DS - INTEGRATE - added js for accordion headers to vrf.js"
    },
    {
        "ID" : 62,
        "Date": "7/26/2023",
        "Changeset": "3505639",
        "File": ["$/Markups/VRF/VRF-docs/html/accordion.html"
                ],
        "Comment": "DS - INTEGRATE - initial check in for accordion component"
    },
    {
        "ID" : 63,
        "Date": "7/26/2023",
        "Changeset": "3506257",
        "File": ["$/Markups/VRF/VRF-docs/virgin/assets-accordion.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "DS - INTEGRATE - added assets-accordion.html"
    },
    {
        "ID" : 64,
        "Date": "7/26/2023",
        "Changeset": "3506269",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/virgin/assets-tooltips.html"
                ],
        "Comment": "KM - INTEGRATE - Added dialog with interactive content"
    },
    {
        "ID" : 65,
        "Date": "7/26/2023",
        "Changeset": "3506272",
        "File": ["$/Markups/VRF/VRF-docs/virgin/assets-links.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-tags.html",
                "$/Markups/VRF/VRF-docs/virgin/brand-effect-style.html",
                "$/Markups/VRF/VRF-docs/virgin/brf-grids.html"
                ],
        "Comment": "DS - IGNORE - reupdated html to include correct script and style srcs"
    },
    {
        "ID" : 66,
        "Date": "7/26/2023",
        "Changeset": "3506423",
        "File": ["$/Markups/VRF/VRF-docs/virgin/sidebar.html",
                "$/Markups/VRF/VRF-docs/virgin/what-is-vrf.html"
                ],
        "Comment": "CD - INTEGRATE - Add What is VRF"
    },
    {
        "ID" : 67,
        "Date": "7/26/2023",
        "Changeset": "3506571",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/html/input-fields.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-input-fields.html"
                ],
        "Comment": "LR - INTEGRATE - added checkboxes components and update dropdown"
    },
    {
        "ID" : 68,
        "Date": "7/27/2023",
        "Changeset": "3507030",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/virgin/assets-radio-button.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "JJF - INTEGRATE - Add assets-radio-button.html"
    },
    {
        "ID" : 69,
        "Date": "7/27/2023",
        "Changeset": "3507827",
        "File": ["$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - delete old files from core vrf"
    },
    {
        "ID" : 71,
        "Date": "7/27/2023",
        "Changeset": "3507890",
        "File": ["$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - INTEGRATE - Added new icon files and updated icon css"
    },
    {
        "ID" : 72,
        "Date": "7/27/2023",
        "Changeset": "3507906",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
                ],
        "Comment": "BFS - INTEGRATE - Aligned vrf-utilities changes in Pssp and vrf core"
    },
    {
        "ID" : 73,
        "Date": "7/27/2023",
        "Changeset": "3508109",
        "File": ["$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-scrollbar.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "CD - INTEGRATE - Add Scrollbar"
    },
    {
        "ID" : 74,
        "Date": "7/27/2023",
        "Changeset": "3508583",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-input-fields.html"
                ],
        "Comment": "KM - IGNORE - Updated search field icon and focus outline"
    },
    {
        "ID" : 75,
        "Date": "7/27/2023",
        "Changeset": "3508639",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-prices.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "KM - INTEGRATE - Added assets-prices.html"
    },
    {
        "ID" : 76,
        "Date": "7/27/2023",
        "Changeset": "3509234",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/virgin/assets-radio-button.html"
                ],
        "Comment": "JJF - INTEGRATE - Update assets-radio-button.html"
    },
    {
        "ID" : 77,
        "Date": "7/27/2023",
        "Changeset": "3509315",
        "File": ["$/Markups/VRF/VRF-docs/html/tags.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-tags.html"
                ],
        "Comment": "DS - INTEGRATE - assets-tags.html added suggestion text"
    },
    {
        "ID" : 78,
        "Date": "7/27/2023",
        "Changeset": "3509315",
        "File": ["$/Markups/VRF/VRF-docs/html/tags.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-tags.html"
                ],
        "Comment": "DS - INTEGRATE - assets-tags.html added suggestion text"
    },
    {
        "ID" : 79,
        "Date": "7/27/2023",
        "Changeset": "3509683",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "BFS - INTEGRATE - Aligned vrf css from vrf vs Pssp Core vile"
    },
    {
        "ID" : 80,
        "Date": "7/27/2023",
        "Changeset": "3510215",
        "File": ["$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html",
                "$/Markups/VRF/VRF-docs/virgin/vrf-strategies.html"
                ],
        "Comment": "CD - INTEGRATE - Add VRF Strategies"
    },
    {
        "ID" : 81,
        "Date": "7/27/2023",
        "Changeset": "3510232",
        "File": ["$/Markups/VRF/VRF-docs/virgin/vrf-layout-breakpoints.html"
                ],
        "Comment": "CD - INTEGRATE - Add Guideline Breakpoints"
    },
    {
        "ID" : 82,
        "Date": "7/27/2023",
        "Changeset": "3510740",
        "File": ["$/Markups/VRF/VRF-docs/virgin/vrf-performance.html"
                ],
        "Comment": "CD - INTEGRATE - Add Performance"
    },
    {
        "ID" : 83,
        "Date": "7/27/2023",
        "Changeset": "3510853",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "JJF - INTEGRATE - Fixed specificity for modals"
    },
    {
        "ID" : 84,
        "Date": "7/28/2023",
        "Changeset": "3511403",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/Dev/PSSP/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js"
                ],
        "Comment": "DS - INTEGRATE - sync docs and pssp core for links and accordion updates"
    },
    {
        "ID" : 85,
        "Date": "7/28/2023",
        "Changeset": "3511409",
        "File": ["$/Markups/VRF/VRF-docs/html/accordion.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-accordion.html"
                ],
        "Comment": "DS - INTEGRATE - accordion html and js update"
    },
    {
        "ID" : 86,
        "Date": "7/28/2023",
        "Changeset": "3511410",
        "File": ["$/Markups/VRF/VRF-docs/html/links.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-links.html"
                ],
        "Comment": "DS - INTEGRATE - links html icons switched to img update"
    },
    {
        "ID" : 87,
        "Date": "7/28/2023",
        "Changeset": "3511456",
        "File": ["$/Markups/VRF/VRF-docs/virgin/assets-icons.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "BFS - INTEGRATE - Added assets icons initial"
    },
    {
        "ID" : 88,
        "Date": "7/28/2023",
        "Changeset": "3511467",
        "File": ["$/Markups/VRF/VRF-docs/virgin/assets-icons.html"
                ],
        "Comment": "BFS - INTEGRATE - Added additional assets icons initial html"
    },
    {
        "ID" : 89,
        "Date": "7/28/2023",
        "Changeset": "3511829",
        "File": ["$/Markups/VRF/VRF-docs/virgin/vrf-strategies.html"
                ],
        "Comment": "CD - INTEGRATE - Update Guidelines Strategies Links"
    },
    {
        "ID" : 90,
        "Date": "7/28/2023",
        "Changeset": "3511858",
        "File": ["$/Markups/VRF/VRF-docs/documents/BRF-guidelines-and-process-strategy.pptx",
                "$/Markups/VRF/VRF-docs/documents/VRF-guidelines-and-process-strategy.pptx",
                "$/Markups/VRF/VRF-docs/virgin/vrf-strategies.html"
                ],
        "Comment": "CD - INTEGRATE -Update Guidelines Strategies Links"
    },
    {
        "ID" : 91,
        "Date": "7/28/2023",
        "Changeset": "3512583",
        "File": ["$/Markups/VRF/VRF-docs/core/js/vrf.js"
                ],
        "Comment": "KM - IGNORE - refactor tooltip initialization and fixed tooltip hide on escape key"
    },
    {
        "ID" : 92,
        "Date": "7/28/2023",
        "Changeset": "3512604",
        "File": ["$/Markups/VRF/VRF-docs/html/starburst.html",
                "$/Markups/VRF/VRF-docs/virgin/brand-starburst.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "DS - INTEGRATE - added brand-starburst.html"
    },
    {
        "ID" : 93,
        "Date": "7/28/2023",
        "Changeset": "3512625",
        "File": ["$/Markups/VRF/VRF-docs/html/plus-up.html",
                "$/Markups/VRF/VRF-docs/virgin/brand-plus-up-graphic.html"
                ],
        "Comment": "DS - INTEGRATE - added brand-plus-up-graphic.html"
    },
    {
        "ID" : 94,
        "Date": "7/28/2023",
        "Changeset": "3513200",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/virgin/assets-checkbox-button.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-input-fields.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "LR - INTEGRATE -  update JS and CSS checkbox components"
    },
    {
        "ID" : 95,
        "Date": "7/28/2023",
        "Changeset": "3513517",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-terms.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "KM - INTEGRATE - added assets-terms.html"
    },
    {
        "ID" : 96,
        "Date": "7/28/2023",
        "Changeset": "3513623",
        "File": ["$/Markups/VRF/VRF-docs/virgin/sidebar.html",
                "$/Markups/VRF/VRF-docs/virgin/vrf-cheatsheet.html"
                ],
        "Comment": "JJF - INTEGRATE - Add vrf-cheatsheet.html"
    },
    {
        "ID" : 97,
        "Date": "7/28/2023",
        "Changeset": "3513844",
        "File": ["$/Markups/VRF/VRF-docs/assets/img/plus_up",
                "$/Markups/VRF/VRF-docs/assets/img/starburst"
                ],
        "Comment": "DS - IGNORE - plus up, starburst img assets upload"
    },
    {
        "ID" : 98,
        "Date": "7/31/2023",
        "Changeset": "3515392",
        "File": ["$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - IGNORE - removed old icons files for both vrf and pssp"
    },
    {
        "ID" : 99,
        "Date": "7/31/2023",
        "Changeset": "3515393",
        "File": ["$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - INTEGRATE - Added new ficon files from request and added new css style for vrf-icon in both pssp and docs"
    },
    {
        "ID" : 100,
        "Date": "7/31/2023",
        "Changeset": "3515400",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
                ],
        "Comment": "BFS - Aligned vrf utilieis css of pssp and core files"
    },
    {
        "ID" : 101,
        "Date": "7/31/2023",
        "Changeset": "3516139",
        "File": ["$/Markups/VRF/VRF-docs/virgin/vrf-cheatsheet.html"
                ],
        "Comment": "JJF - INTEGRATE - Update vrf-cheatsheet.html"
    },
    {
        "ID" : 102,
        "Date": "7/31/2023",
        "Changeset": "3516168",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/Dev/PSSP/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js"
                ],
        "Comment": "DS - INTEGRATE - sync core css js update"
    },
    {
        "ID" : 103,
        "Date": "7/31/2023",
        "Changeset": "3516183",
        "File": ["$/Markups/VRF/VRF-docs/html/accordion.html",
                "$/Markups/VRF/VRF-docs/html/links.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-accordion.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-links.html"
                ],
        "Comment": "DS - INTEGRATE - update on assets-accordion, assets-links"
    },
    {
        "ID" : 104,
        "Date": "7/31/2023",
        "Changeset": "3516672",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/html/input-fields.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-input-fields.html"
                ],
        "Comment": "LR - INTEGRATE - update dropdown input fields and added iconToggle for JS"
    },
    {
        "ID" : 105,
        "Date": "7/31/2023",
        "Changeset": "3516995",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-modals.html"
                ],
        "Comment": "JJF - INTEGRATE - Add a fullscreen modal in assets-modals.html."
    },
    {
        "ID" : 106,
        "Date": "7/31/2023",
        "Changeset": "3517081",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "DS - INTEGRATE - sync core css for skip link"
    },
    {
        "ID" : 107,
        "Date": "7/31/2023",
        "Changeset": "3517091",
        "File": ["$/Markups/VRF/VRF-docs/html/tags.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-tags.html"
                ],
        "Comment": "DS - IGNORE - update classes for assets-tags.html"
    },
    {
        "ID" : 108,
        "Date": "7/31/2023",
        "Changeset": "3517114",
        "File": ["$/Markups/VRF/VRF-docs/html/skip-link.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-skip-link.html"
                ],
        "Comment": "DS - INTEGRATE - added assets-skip-link.html"
    },
    {
        "ID" : 109,
        "Date": "7/31/2023",
        "Changeset": "3517149",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/virgin/assets-toggles.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "CD - INTEGRATE - Add Toggle Label"
    },
    {
        "ID" : 110,
        "Date": "7/31/2023",
        "Changeset": "3517265",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/virgin/assets-range-slider.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "KM - INTEGRATE - Added assets-range-slider.html"
    },
    {
        "ID" : 111,
        "Date": "7/31/2023",
        "Changeset": "3517379",
        "File": ["$/Markups/VRF/VRF-docs/virgin/brand-logo.html"
                ],
        "Comment": "BFS - INTEGRATE - Updated logo file source made it based 64 svg"
    },
    {
        "ID" : 112,
        "Date": "7/31/2023",
        "Changeset": "3517642",
        "File": ["$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - IGNORE - Remove old icon files"
    },
    {
        "ID" : 113,
        "Date": "7/31/2023",
        "Changeset": "3517694",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf-icons.css",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - INTEGRATE - added new icon files and updated vrf-icon css"
    },
    {
        "ID" : 114,
        "Date": "7/31/2023",
        "Changeset": "3518098",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-radio-button.html"
                ],
        "Comment": "JJF - INTEGRATE - Restructure radio buttons css"
    },
    {
        "ID" : 115,
        "Date": "7/31/2023",
        "Changeset": "3518150",
        "File": ["$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - IGNORE - removed  latest icon"
    },
    {
        "ID" : 116,
        "Date": "7/31/2023",
        "Changeset": "3518199",
        "File": ["$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - IGNORE - added old icon files for restrart adding icons"
    },
    {
        "ID" : 117,
        "Date": "7/31/2023",
        "Changeset": "3518360",
        "File": ["$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - IGNORE - Removed old icon file for testing"
    },
    {
        "ID" : 118,
        "Date": "7/31/2023",
        "Changeset": "3518366",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf-icons.css",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2",
                "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - INTEGRATE - retain icon spacings in figma and updated vrf-icons in pssp and core"
    },
    {
        "ID" : 119,
        "Date": "7/31/2023",
        "Changeset": "3518368",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "BFS - INTEGRATE  - updated headline small line height"
    },
    {
        "ID" : 120,
        "Date": "8/1/2023",
        "Changeset": "3518547",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/html/input-fields.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-input-fields.html"
                ],
        "Comment": "LR - INTEGRATE - update input dropdown icons"
    },
    {
        "ID" : 121,
        "Date": "8/1/2023",
        "Changeset": "3518639",
        "File": ["$/Markups/VRF/VRF-docs/virgin/assets-links.html"
                ],
        "Comment": "BFS - INTERATE - Added additional class for the back links due to updated icon file"
    },
    {
        "ID" : 122,
        "Date": "8/1/2023",
        "Changeset": "3518941",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-terms.html"
                ],
        "Comment": "KM - IGNORE - updated icons for assets-terms.html"
    },
    {
        "ID" : 123,
        "Date": "8/1/2023",
        "Changeset": "3519206",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/virgin/assets-toggles.html"
                ],
        "Comment": "LR - INTEGRATE - Added toggle switch for desktop"
    },
    {
        "ID" : 124,
        "Date": "8/1/2023",
        "Changeset": "3519544",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/html/input-fields.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-input-fields.html"
                ],
        "Comment": "LR - INTEGRATE  - Added Input typebox"
    },
    {
        "ID" : 125,
        "Date": "8/1/2023",
        "Changeset": "3519916",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "JJF - INTEGRATE - Update modals component"
    },
    {
        "ID" : 126,
        "Date": "8/1/2023",
        "Changeset": "3520140",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
                ],
        "Comment": "BFS - Aligned vrf utilities styles of pssp and vrf docs"
    },
    {
        "ID" : 127,
        "Date": "8/2/2023",
        "Changeset": "3521958",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
                ],
        "Comment": "BFS - INTEGRATE - Aligend vrf core and vrf utilities css for both Docs and Pssp core"
    },
    {
        "ID" : 128,
        "Date": "8/2/2023",
        "Changeset": "3521958",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
                ],
        "Comment": "BFS - INTEGRATE - Aligend vrf core and vrf utilities css for both Docs and Pssp core"
    },
    {
        "ID" : 129,
        "Date": "8/2/2023",
        "Changeset": "3522010",
        "File": ["$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - INTEGRATE - Aligend vrf core and vrf utilities css for both Docs and Pssp core"
    },
    {
        "ID" : 130,
        "Date": "8/2/2023",
        "Changeset": "3522019",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf-icons.css",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2",
                "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - INTEGRATE - Added new set of icons, updated vrf-icon css file in both pssp and docs core, and added poppins woff in core."
    },
    {
        "ID" : 131,
        "Date": "8/2/2023",
        "Changeset": "3522346",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
                ],
        "Comment": "BFS - INTEGRATE - Aligned vrf utilities pssp core and docs"
    },
    {
        "ID" : 132,
        "Date": "8/2/2023",
        "Changeset": "3522374",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-modals.html"
                ],
        "Comment": "JJF - INTEGRATE - Restructure css class for extra large modal component"
    },
    {
        "ID" : 133,
        "Date": "8/2/2023",
        "Changeset": "3522482",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-tables.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "CD - INTEGRATE - Add Table assets-tables.html"
    },
    {
        "ID" : 134,
        "Date": "8/2/2023",
        "Changeset": "3523163",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "DS - INTEGRATE - sync core css for links update"
    },
    {
        "ID" : 135,
        "Date": "8/2/2023",
        "Changeset": "3523169",
        "File": ["$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/html/accordion.html",
                "$/Markups/VRF/VRF-docs/html/links.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-accordion.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-links.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "DS - INTEGRATE - links with icons structure update"
    },
    {
        "ID" : 136,
        "Date": "8/2/2023",
        "Changeset": "3523541",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
                ],
        "Comment": "DS - INTEGRATE - sync core css for starburst updates"
    },
    {
        "ID" : 137,
        "Date": "8/2/2023",
        "Changeset": "3523546",
        "File": ["$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/html/starburst.html",
                "$/Markups/VRF/VRF-docs/virgin/brand-starburst.html"
                ],
        "Comment": "DS - INTEGRATE - convert brand-starburst graphic to html"
    },
    {
        "ID" : 138,
        "Date": "8/2/2023",
        "Changeset": "3523553",
        "File": ["$/Markups/VRF/VRF-docs/assets/img/starburst"
                ],
        "Comment": "DS - IGNORE - remove startburst images"
    },
    {
        "ID" : 139,
        "Date": "8/2/2023",
        "Changeset": "3523573",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "CD - IGNORE - Move styles above spacers vrf.css"
    },
    {
        "ID" : 140,
        "Date": "8/2/2023",
        "Changeset": "3523576",
        "File": ["$/Markups/VRF/VRF-docs/virgin/assets-filters.html"
                ],
        "Comment": "CD - INTEGRATE - Add Filters assets-filters.html"
    },
    {
        "ID" : 141,
        "Date": "8/2/2023",
        "Changeset": "3523644",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "DS - INTEGRATE - sync core css for links update"
    },
    {
        "ID" : 142,
        "Date": "8/2/2023",
        "Changeset": "3523845",
        "File": ["$/Markups/VRF/VRF-docs/virgin/assets-tooltips.html"
                ],
        "Comment": "KM - INTEGRATE - Added tooltip password"
    },
    {
        "ID" : 143,
        "Date": "8/2/2023",
        "Changeset": "3523871",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "BFS - INTEGRATE - Aligned vrf core file of pssp and docs"
    },
    {
        "ID" : 144,
        "Date": "8/2/2023",
        "Changeset": "3523899",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "BFS - INTEGRATE - Aligned vrf js of pssp and docs core"
    },
    {
        "ID" : 145,
        "Date": "8/3/2023",
        "Changeset": "3525526",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "JJF - INTEGRATE - Modal Scrolling long content behavior 1"
    },
    {
        "ID" : 146,
        "Date": "8/3/2023",
        "Changeset": "3526251",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
                ],
        "Comment": "JJF - INTEGRATE - Aligend vrf core and vrf utilities css for both Docs and Pssp core"
    },
    {
        "ID" : 147,
        "Date": "8/3/2023",
        "Changeset": "3526450",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-placeholders.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html",
                "$/Markups/VRF/VRF-docs/virgin/assets/img/device_specs_acce_false.png",
                "$/Markups/VRF/VRF-docs/virgin/assets/img/device_specs_acce_true.png"
                ],
        "Comment": "KM - INTEGRATE - Added assets-placeholders.html"
    },
    {
        "ID" : 148,
        "Date": "8/3/2023",
        "Changeset": "3526882",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "DS - INTEGRATE - fix for links issue, update core css"
    },
    {
        "ID" : 149,
        "Date": "8/3/2023",
        "Changeset": "3526893",
        "File": ["$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/html/bar-chart.html"
                ],
        "Comment": "DS - INTEGRATE - initial check in for bar-chart.html"
    },
    {
        "ID" : 150,
        "Date": "8/3/2023",
        "Changeset": "3527139",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/layouts-placeholders.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "CD - INTEGRATE - Add Image Placeholder layouts-placeholders.html"
    },
    {
        "ID" : 151,
        "Date": "8/4/2023",
        "Changeset": "3528708",
        "File": ["$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "CD - INTEGRATE - Remove Layout Placeholder"
    },
    {
        "ID" : 152,
        "Date": "8/4/2023",
        "Changeset": "3528720",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "CD - INTEGRATE - Remove Layout Placeholder"
    },
    {
        "ID" : 153,
        "Date": "8/4/2023",
        "Changeset": "3528963",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-filters.html"
                ],
        "Comment": "CD - INTEGRATE - Add search filter assets-filters.html"
    },
    {
        "ID" : 154,
        "Date": "8/4/2023",
        "Changeset": "3529068",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/html/input-fields.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-input-fields.html"
                ],
        "Comment": "LR - INTEGRATE - update input fields width"
    },
    {
        "ID" : 155,
        "Date": "8/4/2023",
        "Changeset": "3529143",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/virgin/assets-filters.html"
                ],
        "Comment": "CD - INTEGRATE - Update Filters assets-filters.html"
    },
    {
        "ID" : 156,
        "Date": "8/4/2023",
        "Changeset": "3529227",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js"
                ],
        "Comment": "CD - INTEGRATE - Update Toggle Label behavior and focus outline"
    },
    {
        "ID" : 157,
        "Date": "8/4/2023",
        "Changeset": "3529314",
        "File": ["$/Markups/VRF/Dev/PSSP/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js"
                ],
        "Comment": "DS - INTEGRATE - sync core js for bar-chart component"
    },
    {
        "ID" : 158,
        "Date": "8/4/2023",
        "Changeset": "3529315",
        "File": ["$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/html/bar-chart.html"
                ],
        "Comment": "DS - INTEGRATE - bar-chart.html update"
    },
    {
        "ID" : 159,
        "Date": "8/4/2023",
        "Changeset": "3529397",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/js/vrf.js",
                "$/Markups/VRF/VRF-docs/virgin/assets-toasters.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "KM - INTEGRATE - Added assets-toasters.html"
    },
    {
        "ID" : 160,
        "Date": "8/4/2023",
        "Changeset": "3529434",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
                ],
        "Comment": "BFS - INTEGRATE - aligned vrf and utitilies of pssp and docs"
    },
    {
        "ID" : 161,
        "Date": "8/4/2023",
        "Changeset": "3529725",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-data-wheel.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "LR - INTEGRATE - initial check-in data wheel components"
    },
    {
        "ID" : 162,
        "Date": "8/7/2023",
        "Changeset": "3530919",
        "File": ["$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - IGNORE - Delete old files of icon"
    },
    {
        "ID" : 163,
        "Date": "8/7/2023",
        "Changeset": "3530921",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf-icons.css",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2",
                "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - INTEGRATE - Aligned new icon files and icon css"
    },
    {
        "ID" : 164,
        "Date": "8/7/2023",
        "Changeset": "3530977",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-data-wheel.html"
                ],
        "Comment": "LR - INTEGRATE - Update data wheel infinity icons"
    },
    {
        "ID" : 165,
        "Date": "8/7/2023",
        "Changeset": "3530980",
        "File": ["$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "JBT - INTEGRATE - add sidebar pageloader"
    },
    {
        "ID" : 166,
        "Date": "8/7/2023",
        "Changeset": "3530981",
        "File": ["$/Markups/VRF/VRF-docs/virgin/assets-pageloader.html"
                ],
        "Comment": "JBT - INTEGRATE - Add assets-pageloader.html"
    },
    {
        "ID" : 167,
        "Date": "8/7/2023",
        "Changeset": "3530999",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
                ],
        "Comment": "DS - INTEGRATE - sync core and utilities css for bar-chart update"
    },
    {
        "ID" : 168,
        "Date": "8/7/2023",
        "Changeset": "3531027",
        "File": ["$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/html/bar-chart.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-bar-chart.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "DS - INTEGRATE - added assets-bar-chart.html"
    },
    {
        "ID" : 169,
        "Date": "8/7/2023",
        "Changeset": "3531290",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "CD - INTEGRATE - Update search filter focus outline"
    },
    {
        "ID" : 170,
        "Date": "8/7/2023",
        "Changeset": "3531441",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "DS - INTEGRATE - sync core css for wrapped text on icon-right for links"
    },
    {
        "ID" : 171,
        "Date": "8/7/2023",
        "Changeset": "3531445",
        "File": ["$/Markups/VRF/VRF-docs/html/links.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-links.html"
                ],
        "Comment": "DS - IGNORE - updated assets-links to show wrapped text on icon-right"
    },
    {
        "ID" : 172,
        "Date": "8/7/2023",
        "Changeset": "3531446",
        "File": ["$/Markups/VRF/VRF-docs/html/bar-chart.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-bar-chart.html"
                ],
        "Comment": "DS - IGNORE - spacing update on assets-bar-chart"
    },
    {
        "ID" : 173,
        "Date": "8/7/2023",
        "Changeset": "3531495",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-modals.html"
                ],
        "Comment": "JJF - INTEGRATE - Modal focus outline"
    },
    {
        "ID" : 174,
        "Date": "8/7/2023",
        "Changeset": "3531584",
        "File": ["$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - IGNORE - deleted old icon file for pssp and docs core"
    },
    {
        "ID" : 175,
        "Date": "8/7/2023",
        "Changeset": "3531587",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf-icons.css",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2",
                "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
                ],
        "Comment": "BFS - INTEGRATE - Added new icon file and aligned icon css for pssp and docs core"
    },
    {
        "ID" : 176,
        "Date": "8/7/2023",
        "Changeset": "3531636",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/virgin/assets-tabs.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "KM - INTEGRATE - Added assets-tabs.html"
    },
    {
        "ID" : 177,
        "Date": "8/8/2023",
        "Changeset": "3532158",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "DS - INTEGRATE - sync core css for bar chart mobile viewport update"
    },
    {
        "ID" : 178,
        "Date": "8/8/2023",
        "Changeset": "3532162",
        "File": ["$/Markups/VRF/VRF-docs/html/bar-chart.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-bar-chart.html"
                ],
        "Comment": "DS - INTEGRATE - updated mobile viewport for assets-bar-chart"
    },
    {
        "ID" : 179,
        "Date": "8/8/2023",
        "Changeset": "3532395",
        "File": ["$/Markups/VRF/VRF-docs/core/js/vrf.js"
                ],
        "Comment": "KM - IGNORE - Applied tooltip hide on viewport resize"
    },
    {
        "ID" : 180,
        "Date": "8/8/2023",
        "Changeset": "3532529",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
                ],
        "Comment": "BFS - INTEGRATE - Aligned vrf and vrf utilities of Docs and pssp core files"
    },
    {
        "ID" : 181,
        "Date": "8/8/2023",
        "Changeset": "3532859",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "CD - INTEGRATE - Update scrollbar size and track color"
    },
    {
        "ID" : 182,
        "Date": "8/8/2023",
        "Changeset": "3533313",
        "File": ["$/Markups/VRF/VRF-docs/virgin/vrf-strategies.html",
                "$/Markups/VRF/VRF-docs/virgin/what-is-vrf.html"
                ],
        "Comment": "BFS - INTEGRATE - Added new info and bootstrap link in the vrf strategies and what is vrf"
    },
    {
        "ID" : 183,
        "Date": "8/8/2023",
        "Changeset": "3533518",
        "File": ["$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/html/card.html"
                ],
        "Comment": "DS - INTEGRATE - initial check in for radio cards"
    },
    {
        "ID" : 184,
        "Date": "8/8/2023",
        "Changeset": "3533642",
        "File": ["$/Markups/VRF/VRF-docs/core/js/vrf.js"
                ],
        "Comment": "KM - INTEGRATE - Applied tooltip standard distance"
    },
    {
        "ID" : 185,
        "Date": "8/9/2023",
        "Changeset": "3534498",
        "File": ["$/Markups/VRF/VRF-docs/virgin/assets-data-wheel.html"
                ],
        "Comment": "LR - INTEGRATE - Update data wheel accessibility"
    },
    {
        "ID" : 186,
        "Date": "8/9/2023",
        "Changeset": "3534655",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf.css"
                ],
        "Comment": "DS - INTEGRATE - sync core css for links hover and focus update"
    },
    {
        "ID" : 187,
        "Date": "8/9/2023",
        "Changeset": "3534672",
        "File": ["$/Markups/VRF/VRF-docs/html/links.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-links.html"
                ],
        "Comment": "DS - IGNORE - markup update on assets-links.html"
    },
    {
        "ID": 188,
        "Date": "8/9/2023",
        "Changeset": "3535325",
        "File": ["$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "KM - INTEGRATE - Minor update for tooltip if has data-bs-offset"
    },
    {
        "ID": 189,
        "Date": "8/9/2023",
        "Changeset": "3535419",
        "File": ["$/Markups/VRF/VRF-docs/content/css/docs.css",
                "$/Markups/VRF/VRF-docs/content/js/docs.js",
                "$/Markups/VRF/VRF-docs/virgin/assets-buttons.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-scrollbar.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-tables.html",
                "$/Markups/VRF/VRF-docs/virgin/assets-toggles.html",
                "$/Markups/VRF/VRF-docs/virgin/brand-colors.html",
                "$/Markups/VRF/VRF-docs/virgin/brand-font.html",
                "$/Markups/VRF/VRF-docs/virgin/brand-logo.html",
                "$/Markups/VRF/VRF-docs/virgin/brand-plus-up-graphic.html",
                "$/Markups/VRF/VRF-docs/virgin/brand-starburst.html",
                "$/Markups/VRF/VRF-docs/virgin/brand-style-guide.html",
                "$/Markups/VRF/VRF-docs/virgin/brand-typography.html",
                "$/Markups/VRF/VRF-docs/virgin/brf-grids.html",
                "$/Markups/VRF/VRF-docs/virgin/brf-supported-browsers.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html",
                "$/Markups/VRF/VRF-docs/virgin/vrf-about.html",
                "$/Markups/VRF/VRF-docs/virgin/vrf-grids.html",
                "$/Markups/VRF/VRF-docs/virgin/vrf-layout-breakpoints.html",
                "$/Markups/VRF/VRF-docs/virgin/vrf-performance.html",
                "$/Markups/VRF/VRF-docs/virgin/vrf-strategies.html",
                "$/Markups/VRF/VRF-docs/virgin/vrf-supported-browsers.html",
                "$/Markups/VRF/VRF-docs/virgin/what-is-vrf.html"
                ],
        "Comment": "JJF - INTEGRATE - Update sidebar and html files"
    },
    {
        "ID": 190,
        "Date": "8/9/2023",
        "Changeset": "3535432",
        "File": ["$/Markups/VRF/VRF-docs/virgin/assets-footer-form.html",
                "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
                ],
        "Comment": "CD - INTEGRATE - Add assets-footer-form.html"
    },
    {
        "ID": 191,
        "Date": "8/9/2023",
        "Changeset": "3535555",
        "File": ["$/Markups/VRF/VRF-docs/virgin/vrf-changelog.html",
                "$/Markups/VRF/VRF-docs/virgin/vrf-cheatsheet.html"
                ],
        "Comment": "JJF - INTEGRATE - Fixed docs table header"
    },
    {
        "ID": 192,
        "Date": "8/9/2023",
        "Changeset": "3535611",
        "File": ["$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2",
                "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css"
                ],
        "Comment": "BFS - INTEGRATE - Added new icon file with check solo for step flow icon and updated vrf-icon css"
    },
    {
        "ID": 193,
        "Date": "8/9/2023",
        "Changeset": "3535690",
        "File": ["$/Markups/VRF/VRF-docs/virgin/index.html"
                ],
        "Comment": "JJF - INTEGRATE - Update index.html"
    },
    {
        "ID": 194,
        "Date": "8/9/2023",
        "Changeset": "3535806",
        "File": ["$/Markups/VRF/VRF-docs/virgin/assets-filters.html"
                ],
        "Comment": "CD - INTEGRATE - Change icon for Search Filter"
    },
    {
        "ID": 195,
        "Date": "8/10/2023",
        "Changeset": "3537156",
        "File": ["$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2",
            "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css"
        ],
        "Comment": "BFS - INTEGRATE - Added new set of icons including the internet colored and steve icon"
    },
    {
        "ID": 196,
        "Date": "8/10/2023",
        "Changeset": "3537256",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "BFS - INTEGRATE - changed location of the font family poppins and added copy large infix"
    },
    {
        "ID": 197,
        "Date": "8/10/2023",
        "Changeset": "3537876",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-simple-header.html",
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
        ],
        "Comment": "LR - INTEGRATE - Added simple header components"
    },
    {
        "ID": 198,
        "Date": "8/10/2023",
        "Changeset": "3537889",
        "File": ["$/Markups/VRF/Dev/PSSP/core/css/vrf.css"
        ],
        "Comment": "LR - INTEGRATE - sync core css for simple header"
    },
    {
        "ID": 199,
        "Date": "8/11/2023",
        "Changeset": "3538007",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css",
            "$/Markups/VRF/VRF-docs/core/js/vrf.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-step-flow.html",
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
        ],
        "Comment": "KM - INTEGRATE - Initial check-in for assets-step-flow.html"
    },
    {
        "ID": 200,
        "Date": "8/11/2023",
        "Changeset": "3538056",
        "File": ["$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css",
            "$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
            "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css"
        ],
        "Comment": "DS - INTEGRATE - sync core and utilities css for assets-links revisions"
    },
    {
        "ID": 201,
        "Date": "8/11/2023",
        "Changeset": "3538061",
        "File": ["$/Markups/VRF/VRF-docs/html/accordion.html",
            "$/Markups/VRF/VRF-docs/html/links.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-accordion.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-links.html"
        ],
        "Comment": "DS - INTEGRATE - links with icons revision update"
    },
    {
        "ID": 202,
        "Date": "8/11/2023",
        "Changeset": "3538335",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
        ],
        "Comment": "BFS - INTEGRATED - Added additional css styles width and borders"
    },
    {
        "ID": 203,
        "Date": "8/11/2023",
        "Changeset": "3538484",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/Dev/PSSP/core/css/vrf.css"
        ],
        "Comment": "DS - INTEGRATE - sync core css for modal dimension fix, modal close btn focus on shown"
    },
    {
        "ID": 204,
        "Date": "8/11/2023",
        "Changeset": "3538489",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-modals.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-tooltips.html"
        ],
        "Comment": "DS - INTEGRATE - modal dimension fix, modal close btn focus fix"
    },
    {
        "ID": 205,
        "Date": "8/11/2023",
        "Changeset": "3538614",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "LR - INTEGRATE - update dropdown css while using arrow keys"
    },
    {
        "ID": 206,
        "Date": "8/11/2023",
        "Changeset": "3538623",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf.css"
        ],
        "Comment": "LR - INTEGRATE - sync core css for dropdown css while using arrow keys"
    },
    {
        "ID": 207,
        "Date": "8/11/2023",
        "Changeset": "3539879",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css",
            "$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
            "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css"
        ],
        "Comment": "DS - INTEGRATE - sync core and utilities css for tooltip modal update"
    },
    {
        "ID": 208,
        "Date": "8/11/2023",
        "Changeset": "3539886",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-tooltips.html"
        ],
        "Comment": "DS - INTEGRATE - assets-modals spacing update"
    },
    {
        "ID": 209,
        "Date": "8/11/2023",
        "Changeset": "3539917",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-tooltips.html"
        ],
        "Comment": "KM - IGNORE - updated tooltip arrow center position"
    },
    {
        "ID": 210,
        "Date": "8/11/2023",
        "Changeset": "3540006",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "JJF - INTEGRATE - Aligend vrf core for both Docs and Pssp core"
    },
    {
        "ID": 211,
        "Date": "8/11/2023",
        "Changeset": "3540062",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "LR - INTEGRATE - aligned vrf and pssp core css"
    },
    {
        "ID": 212,
        "Date": "8/11/2023",
        "Changeset": "3540333",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "LR - INTEGRATE - aligned vrf core for both docs and pssp core css"
    },
    {
        "ID": 213,
        "Date": "8/11/2023",
        "Changeset": "3541133",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css",
            "$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
            "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css"
        ],
        "Comment": "DS - INTEGRATE - sync core and utilities css for radio cards update"
    },
    {
        "ID": 214,
        "Date": "8/11/2023",
        "Changeset": "3541148",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/docs.css",
            "$/Markups/VRF/VRF-docs/html/card.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-cards.html",
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
        ],
        "Comment": "DS - INTEGRATE - added assets-cards.html"
    },
    {
        "ID": 215,
        "Date": "8/11/2023",
        "Changeset": "3541158",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-footer-dock.html",
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html",
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
        ],
        "Comment": "CD - INTEGRATE - Add Footer Dock assets-footer-dock.html"
    },
    {
        "ID": 216,
        "Date": "8/11/2023",
        "Changeset": "3541857",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-step-flow.html"
        ],
        "Comment": "KM - IGNORE - Fixed mobile view for assets-step-flow.html"
    },
    {
        "ID": 217,
        "Date": "8/13/2023",
        "Changeset": "3544122",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-tables.html"
        ],
        "Comment": "JJF - INTEGRATE - Update tables component"
    },
    {
        "ID": 218,
        "Date": "8/14/2023",
        "Changeset": "3545468",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf-utilities.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-footer-dock.html"
        ],
        "Comment": "CD - INTEGRATE - Apply total price dock"
    },
    {
        "ID": 219,
        "Date": "8/14/2023",
        "Changeset": "3545681",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/docs.css",
            "$/Markups/VRF/VRF-docs/content/js/docs.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-modals.html"
        ],
        "Comment": "JJF - INTEGRATE - Added copy text"
    },
    {
        "ID": 220,
        "Date": "8/14/2023",
        "Changeset": "3545799",
        "File": [
            "$/Markups/VRF/VRF-docs/html/card.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-cards.html"
        ],
        "Comment": "DS - IGNORE - radio cards update for a11y reading"
    },
    {
        "ID": 221,
        "Date": "8/14/2023",
        "Changeset": "3546101",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "BFS - INTEGRATE - Modify the table css for the striped table"
    },
    {
        "ID": 222,
        "Date": "8/15/2023",
        "Changeset": "3546785",
        "File": [
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
        ],
        "Comment": "BFS - IGNORE - Deleted old icon files without edit icon filled"
    },
    {
        "ID": 223,
        "Date": "8/15/2023",
        "Changeset": "3546786",
        "File": [
                "$/Markups/VRF/Dev/PSSP/core/css/vrf-icons.css",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2",
                "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
                "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
        ],
        "Comment": "BFS - INTEGRATE - Added new icon edit filled and updated icon files -- aligned vrf icons css file of docs core and pssp core"
    },
    {
        "ID": 224,
        "Date": "8/15/2023",
        "Changeset": "3546792",
        "File": [
                "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
        ],
        "Comment": "JJF - INTEGRATE - Aligend vrf utilities css for both Docs and Pssp core folder"
    },
    {
        "ID": 225,
        "Date": "8/15/2023",
        "Changeset": "3546875",
        "File": [
                "$/Markups/VRF/VRF-docs/content/css/docs.css"
        ],
        "Comment": "JJF - INTEGRATE - Update style for copy text"
    },
    {
        "ID": 226,
        "Date": "8/15/2023",
        "Changeset": "3546882",
        "File": [
                "$/Markups/VRF/VRF-docs/virgin/assets-modals.html"
        ],
        "Comment": "DS - INTEGRATE - modal tooltip fix on assets-modals"
    },
    {
        "ID": 227,
        "Date": "8/15/2023",
        "Changeset": "3547272",
        "File": [
                "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
        ],
        "Comment": "DS - INTEGRATE - sync utilities css with AA_REMOVE_UNUSEDCLASS shelve"
    },
    {
        "ID": 228,
        "Date": "8/15/2023",
        "Changeset": "3547305",
        "File": [
                "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
                "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
        ],
        "Comment": "JJF - INTEGRATE - Aligend vrf.css for both Docs and Pssp core folder"
    },
    {
        "ID": 229,
        "Date": "8/15/2023",
        "Changeset": "3547725",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-filters.html"
        ],
        "Comment": "CD - INTEGRATE - Update filter disabled state accessibility"
    },
    {
        "ID": 230,
        "Date": "8/15/2023",
        "Changeset": "3547893",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-footer-dock.html"
        ],
        "Comment": "CD - INTEGRATE - Update Docks accessibility"
    },
    {
        "ID": 231,
        "Date": "8/15/2023",
        "Changeset": "3548201",
        "File": [
            "$/Markups/VRF/VRF-docs/html/bar-chart.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-bar-chart.html"
        ],
        "Comment": "DS - INTEGRATE - bar chart a11y update from ADD"
    },
    {
        "ID": 232,
        "Date": "8/15/2023",
        "Changeset": "3548370",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-buttons.html"
        ],
        "Comment": "JJF - INTEGRATE - Update asstes-buttons.html with copy-text code"
    },
    {
        "ID": 233,
        "Date": "8/15/2023",
        "Changeset": "3548607",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/js/vrf.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-checkbox-button.html"
        ],
        "Comment": "LR - INTEGRATE - update checkbox js and added copy text"
    },
    {
        "ID": 234,
        "Date": "8/15/2023",
        "Changeset": "3548748",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
            "$/Markups/VRF/Dev/PSSP/core/js/vrf.js"
        ],
        "Comment": "LR - INTEGRATE - sync vrf css and js on pssp core"
    },
    {
        "ID": 235,
        "Date": "8/15/2023",
        "Changeset": "3548840",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-tabs.html"
        ],
        "Comment": "KM - IGNORE - fixed tablist focus outline and mobile overflow"
    },
    {
        "ID": 236,
        "Date": "8/15/2023",
        "Changeset": "3549834",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-tags.html"
        ],
        "Comment": "DS - INTEGRATE - updated copy text for assets-tags.html"
    },
    {
        "ID": 237,
        "Date": "8/16/2023",
        "Changeset": "3549837",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/brand-starburst.html"
        ],
        "Comment": "DS - INTEGRATE - updated copy text for brand-starburst.html"
    },
    {
        "ID": 238,
        "Date": "8/16/2023",
        "Changeset": "3551139",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-scrollbar.html"
        ],
        "Comment": "CD - INTEGRATE - Add copy paste code scrollbar"
    },
    {
        "ID": 239,
        "Date": "8/16/2023",
        "Changeset": "3551144",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-footer-dock.html"
        ],
        "Comment": "CD - INTEGRATE - Add copy paste code to Docks"
    },
    {
        "ID": 240,
        "Date": "8/16/2023",
        "Changeset": "3549854",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/brand-starburst.html"
        ],
        "Comment": "DS - IGNORE - reupdate copy-text for brand-starburst.html"
    },
    {
        "ID": 241,
        "Date": "8/16/2023",
        "Changeset": "3550126",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-skip-link.html"
        ],
        "Comment": "DS - INTEGRATE - updated copy text code for assets-skip-link.html"
    },
    {
        "ID": 242,
        "Date": "8/16/2023",
        "Changeset": "3550510",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "BFS - INTEGRATE - Aligned vrf core css for docs and pssp core -- added additional fix for table striped removed border bottom"
    },
    {
        "ID": 243,
        "Date": "8/16/2023",
        "Changeset": "3551132",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-data-wheel.html"
        ],
        "Comment": "LR - INTEGRATE - added copy text for data wheel components"
    },
    {
        "ID": 244,
        "Date": "8/16/2023",
        "Changeset": "3551167",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-alerts.html"
        ],
        "Comment": "JJF - INTEGRATE - Update copy-text for assets - alerts.html"
    },
    {
        "ID": 245,
        "Date": "8/16/2023",
        "Changeset": "3551202",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-accordion.html"
        ],
        "Comment": "DS - INTEGRATE - updated copy text code for assets-accordion.html"
    },
    {
        "ID": 246,
        "Date": "8/16/2023",
        "Changeset": "3551270",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-range-slider.html"
        ],
        "Comment": "KM  - INTEGRATE - added code snippet for range slider components"
    },
    {
        "ID": 247,
        "Date": "8/16/2023",
        "Changeset": "3551333",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-icons.html"
        ],
        "Comment": "JBT - INTEGRATE - Add new list of icons"
    },
    {
        "ID": 248,
        "Date": "8/16/2023",
        "Changeset": "3551351",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css"
        ],
        "Comment": "JBT - INTEGRATE - add reverse layout  and update color to #131C35"
    },
    {
        "ID": 249,
        "Date": "8/16/2023",
        "Changeset": "3551385",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-data-wheel.html"
        ],
        "Comment": "LR - INTEGRATE - update copy text for data wheel"
    },
    {
        "ID": 250,
        "Date": "8/17/2023",
        "Changeset": "3551936",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-simple-footer.html",
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
        ],
        "Comment": "CP - INTEGRATE - added simple footer"
    },
    {
        "ID": 251,
        "Date": "8/17/2023",
        "Changeset": "3552077",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
        ],
        "Comment": "BFS - IGNORE - Delete old icon file without arrow slim, pin loc, hamburger menu, troubleshoot icons"
    },
    {
        "ID": 252,
        "Date": "8/17/2023",
        "Changeset": "3552089",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf-icons.css",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2",
            "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
        ],
        "Comment": "BFS - INTEGRATE - Aligned updated icon files with additional new icons slim arrows, troubleshoot, pin locaiton, and hamburger-menu, changd the black icon color into midnight"
    },    
    {
        "ID": 253,
        "Date": "8/17/2023",
        "Changeset": "3552233",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-simple-footer.html",
            "$/Markups/VRF/VRF-docs/virgin/assets/img/entrust.png"
        ],
        "Comment": "CP - INTEGRATE - added remaining simple footer"
    },
    {
        "ID": 254,
        "Date": "8/17/2023",
        "Changeset": "3552380",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-icons.html"
        ],
        "Comment": "JBT - INTEGRATE - HTML add latest icons. CSS change font color The ff. styles should be red .icon-Edit-pen and .icon-Forum-message."
    },
    {
        "ID": 255,
        "Date": "8/17/2023",
        "Changeset": "3552412",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf-icons.css"
        ],
        "Comment": "JBT- INTEGRATE - Aligned changes for the ff. .icon-Edit-pen and .icon-Forum-message, color changed to red."
    },
    {
        "ID": 256,
        "Date": "8/17/2023",
        "Changeset": "3552588",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "DS - INTEGRATE - sync core css for bar-chart fix update"
    },
    {
        "ID": 257,
        "Date": "8/17/2023",
        "Changeset": "3552591",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-bar-chart.html",
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "DS - INTEGRATE - assets-bar-chart.html fix update"
    },
    {
        "ID": 258,
        "Date": "8/18/2023",
        "Changeset": "3552977",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-toggles.html"
        ],
        "Comment": "CD - INTEGRATE - Add copy text to Toggle Label"
    },
    {
        "ID": 259,
        "Date": "8/18/2023",
        "Changeset": "3553374",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-tabs.html"
        ],
        "Comment": "KM - INTEGRATE - added code snippet for tabs components"
    },
    {
        "ID": 260,
        "Date": "8/18/2023",
        "Changeset": "3553383",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-placeholders.html"
        ],
        "Comment": "KM - INTEGRATE - added code snippet for placeholders components"
    },
    {
        "ID": 261,
        "Date": "8/18/2023",
        "Changeset": "3553439",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-radio-button.html"
        ],
        "Comment": "JJF - INTEGRATE - Update copy-text for assets-radio-button.html"
    },
    {
        "ID": 262,
        "Date": "8/18/2023",
        "Changeset": "3553489",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-links.html"
        ],
        "Comment": "DS - INTEGRATE - updated copy text code to assets-links.html"
    },
    {
        "ID": 263,
        "Date": "8/18/2023",
        "Changeset": "3553524",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "BFS - INTEGRATE - Added additional style for liquid container in larger desktop and aligned docs core vrf to pssp core vrf"
    },
    {
        "ID": 264,
        "Date": "8/18/2023",
        "Changeset": "3553548",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-toggles.html"
        ],
        "Comment": "LR - INTEGRATE - added code snippet for toggle components"
    },
    {
        "ID": 265,
        "Date": "8/18/2023",
        "Changeset": "3553492",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-filters.html"
        ],
        "Comment": "CD - INTEGRATE - Add copy text to filters"
    },
    {
        "ID": 266,
        "Date": "8/18/2023",
        "Changeset": "3554641",
        "File": [
            "$/Markups/VRF/VRF-docs/core/vrf-utilities.css"
        ],
        "Comment": "CD - INTEGRATE - Apply shelveset BH_VRF_UTILITIES"
    },
    {
        "ID": 267,
        "Date": "8/18/2023",
        "Changeset": "3554882",
        "File": [
            "$/Markups/VRF/VRF-docs/core/vrf-utilities.css"
        ],
        "Comment": "CD - INTEGRATE - Apply shelveset AA_BORDER_DISABLED"
    },
    {
        "ID": 268,
        "Date": "8/18/2023",
        "Changeset": "3555197",
        "File": [
            "$/Markups/VRF/VRF-docs/core/vrf-utilities.css"
        ],
        "Comment": "CD - INTEGRATE - Apply shelveset CN_PSSP_MAVERICK_VRF_UTILITIES_HEIGHT_56"
    },
    {
        "ID": 269,
        "Date": "8/18/2023",
        "Changeset": "3554513",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "JBT - INTEGRATE - Change target to ::before, the  ff. styles should be red  .icon-Edit-pen and .icon-Forum-message"
    },
    {
        "ID": 270,
        "Date": "8/19/2023",
        "Changeset": "3555044",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "DS - INTEGRATE - sync core css for assets-bar-chart overlay fix"
    },
    {
        "ID": 271,
        "Date": "8/19/2023",
        "Changeset": "3555045",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-bar-chart.html"
        ],
        "Comment": "DS - INTEGRATE - assets-bar-chart.html overlay issue fix"
    },
    {
        "ID": 272,
        "Date": "8/19/2023",
        "Changeset": "3555058",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "DS - INTEGRATE - sync/updated core js for assets-bar-chart.html"
    },
    {
        "ID": 273,
        "Date": "8/19/2023",
        "Changeset": "3555154",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "DS - INTEGRATE - sync core css for bar chart fix"
    },
    {
        "ID": 274,
        "Date": "8/19/2023",
        "Changeset": "3555302",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-tables.html"
        ],
        "Comment": "JJF - INTEGRATE - Update copy-text for assets-tables.html"
    },
    {
        "ID": 275,
        "Date": "8/19/2023",
        "Changeset": "3555437",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-terms.html"
        ],
        "Comment": "KM  - INTEGRATE - added code snippet for assets-terms layout"
    },
    {
        "ID": 276,
        "Date": "8/19/2023",
        "Changeset": "3555446",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/brand-plus-up-graphic.html"
        ],
        "Comment": "DS - INTEGRATE - added code snippet for plus up graphic"
    },
    {
        "ID": 277,
        "Date": "8/19/2023",
        "Changeset": "3555456",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "KM - INTEGRATE - Apply shelveset - JEM_PSSP_MAVERICK_TYPOGRAPHY"
    },
    {
        "ID": 278,
        "Date": "8/19/2023",
        "Changeset": "3555482",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
        ],
        "Comment": "KM - INTEGRATE - Apply shelveset - BH_VRF_UTILITIES"
    },
    {
        "ID": 279,
        "Date": "8/22/2023",
        "Changeset": "3559724",
        "File": [
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
        ],
        "Comment": "JBT - INTEGRATE - Update missing mobile icon"
    },
    {
        "ID": 280,
        "Date": "8/22/2023",
        "Changeset": "3560052",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
        ],
        "Comment": "CD - INTEGRATE - Apply .min-w-md-380"
    },
    {
        "ID": 281,
        "Date": "8/22/2023",
        "Changeset": "3560123",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/js/vrf.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-checkbox-button.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-radio-button.html"
        ],
        "Comment": "LR - INTEGRATE - update radio and checkbox button CSS/JS"
    },
    {
        "ID": 282,
        "Date": "8/22/2023",
        "Changeset": "3561044",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-tooltips.html"
        ],
        "Comment": "KM - INTEGRATE - added code snippet for tooltips component"
    },
    {
        "ID": 283,
        "Date": "8/23/2023",
        "Changeset": "3561396",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-bar-chart.html"
        ],
        "Comment": "DS - INTEGRATE - added copy text code for assets-bar-chart.html"
    },
    {
        "ID": 284,
        "Date": "8/23/2023",
        "Changeset": "3561397",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-cards.html"
        ],
        "Comment": "DS - INTEGRATE - added copy text code for assets-cards.html"
    },
    {
        "ID": 285,
        "Date": "8/23/2023",
        "Changeset": "3561602",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-bar-chart.html"
        ],
        "Comment": "DS - INTEGRATE - added padding for chart container on assets-bar-chart.html"
    },
    {
        "ID": 286,
        "Date": "8/24/2023",
        "Changeset": "3564345",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "LR - INTEGRATE - update radio and checkbox css button"
    },
    {
        "ID": 287,
        "Date": "8/24/2023",
        "Changeset": "3564353",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-tables.html"
        ],
        "Comment": "CD - INTEGRATE - Update table striped border"
    },
    {
        "ID": 288,
        "Date": "8/24/2023",
        "Changeset": "3564610",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "DS - INTEGRATE - sync core css for assets-cards.html update"
    },
    {
        "ID": 289,
        "Date": "8/24/2023",
        "Changeset": "3564616",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-cards.html"
        ],
        "Comment": "DS - INTEGRATE - update for icons alignment for assets-cards.html"
    },
    {
        "ID": 290,
        "Date": "8/29/2023",
        "Changeset": "3571272",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-footer-dock.html",
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
        ],
        "Comment": "CD - INTEGRATE - Update Footer Dock"
    },
    {
        "ID": 291,
        "Date": "8/30/2023",
        "Changeset": "3573587",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-footer-form.html"
        ],
        "Comment": "CD - INTEGRATE - Add copy text Footer Form assets-footer-form.html"
    },
    {
        "ID": 292,
        "Date": "8/31/2023",
        "Changeset": "3574175",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "DS - INTEGRATE - core css update for assets-anchor.html"
    },
    {
        "ID": 293,
        "Date": "8/31/2023",
        "Changeset": "3574180",
        "File": [
            "$/Markups/VRF/VRF-docs/html/anchors.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-anchor.html"
        ],
        "Comment": "DS - INTEGRATE - added htmls assets-anchor.html, anchors.html"
    },
    {
        "ID": 294,
        "Date": "8/31/2023",
        "Changeset": "3574184",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
        ],
        "Comment": "DS - INTEGRATE - html update for sidebar.html"
    },
    {
        "ID": 295,
        "Date": "8/31/2023",
        "Changeset": "3575982",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "DS - INTEGRATE - updated core js with same height function"
    },
    {
        "ID": 296,
        "Date": "9/01/2023",
        "Changeset": "3578238",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "DS - INTEGRATE - updated core js for click on space/enter functions"
    },
    {
        "ID": 297,
        "Date": "9/01/2023",
        "Changeset": "3578240",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-accordion.html"
        ],
        "Comment": "DS - IGNORE - updated button classes to use click-on-space-or-enter"
    },
    {
        "ID": 298,
        "Date": "9/02/2023",
        "Changeset": "3579187",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "DS - INTEGRATE - update on barChartInit on core js for hardcoded text"
    },
    {
        "ID": 299,
        "Date": "9/02/2023",
        "Changeset": "3579777",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "DS - INTEGRATE - core js update for click on space"
    },
    {
        "ID": 300,
        "Date": "9/04/2023",
        "Changeset": "3581189",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
        ],
        "Comment": "DS - INTEGRATE - update utilities css helper classes"
    },
    {
        "ID": 301,
        "Date": "9/04/2023",
        "Changeset": "3581217",
        "File": [
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2",
        ],
        "Comment": "JBT - IGNORE - Remove old vrf-icons file"
    },
    {
        "ID": 302,
        "Date": "9/04/2023",
        "Changeset": "3581218",
        "File": [
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2",
        ],
        "Comment": "JBT - INTEGRATE - Add new vrf-icons. new icons: Card and Service-info"
    },
    {
        "ID": 303,
        "Date": "9/04/2023",
        "Changeset": "3581223",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "LR - INTEGRATE - update checkbox css style"
    },
    {
        "ID": 304,
        "Date": "9/04/2023",
        "Changeset": "3581227",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css"
        ],
        "Comment": "JBT - INTEGRATE - New icon classes: Card and Service-info"
    },
    {
        "ID": 305,
        "Date": "9/04/2023",
        "Changeset": "3581271",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css"
        ],
        "Comment": "JBT - IGNORE - Remove path1 and path2 class in vrf-icons.css"
    },
    {
        "ID": 306,
        "Date": "9/04/2023",
        "Changeset": "3581294",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/splide.min.css",
            "$/Markups/VRF/VRF-docs/core/js/splide.min.js"
        ],
        "Comment": "JJF - INTEGRATE - Added splide file to core folder"
    },
    {
        "ID": 307,
        "Date": "9/04/2023",
        "Changeset": "3581290",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-range-slider.html"
        ],
        "Comment": "KM - IGNORE - refactor - moved rangeSlider function to a different file"
    },
    {
        "ID": 308,
        "Date": "9/04/2023",
        "Changeset": "3581296",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/js/vrf.js"
        ],
        "Comment": "KM - INTEGRATE - refactor - sync vrf js (moved rangeSlider function to a different file)"
    },
    {
        "ID": 309,
        "Date": "9/04/2023",
        "Changeset": "3581462",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-simple-header.html"
        ],
        "Comment": "LR - INTEGRATE - update back button and focus outline for simple header components"
    },
    {
        "ID": 310,
        "Date": "9/05/2023",
        "Changeset": "3581912",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-footer-dock.html"
        ],
        "Comment": "CD - INTEGRATE - Update Footer Dock Padding"
    },
    {
        "ID": 311,
        "Date": "9/05/2023",
        "Changeset": "3581917",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
        ],
        "Comment": "CD - INTEGRATE - Add padding 12px"
    },
    {
        "ID": 312,
        "Date": "9/05/2023",
        "Changeset": "3581953",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
        ],
        "Comment": "CD - INTEGRATE - Add vertical, horizontal padding 12px helper class"
    },
    {
        "ID": 313,
        "Date": "9/05/2023",
        "Changeset": "3582039",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "DS - INTEGRATE - update on core css for skip link spacing update"
    },
    {
        "ID": 314,
        "Date": "9/05/2023",
        "Changeset": "3583058",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "KM - IGNORE - refactor (wrapped global namespace functions inside IIFE)"
    },
    {
        "ID": 315,
        "Date": "9/05/2023",
        "Changeset": "3582138",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "DS - INTEGRATE - core css for assets-cards update"
    },
    {
        "ID": 316,
        "Date": "9/05/2023",
        "Changeset": "3582140",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-cards.html"
        ],
        "Comment": "DS - INTEGRATE - assets-cards.html js update for selected card"
    },
    {
        "ID": 317,
        "Date": "9/05/2023",
        "Changeset": "3583174",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-cards.html"
        ],
        "Comment": "DS - IGNORE - added disclaimer text for inline footer script"
    },
    {
        "ID": 318,
        "Date": "9/05/2023",
        "Changeset": "3583244",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/custom.css"
        ],
        "Comment": "KM - INTEGRATE - Added custom.css for VRF custom components"
    },
    {
        "ID": 319,
        "Date": "9/05/2023",
        "Changeset": "3583529",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/custom.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/js/vrf.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-toggles.html"
        ],
        "Comment": "CD - INTEGRATE - Update Toggle Label custom.css and remove custom js vrf.js"
    },
    {
        "ID": 320,
        "Date": "9/06/2023",
        "Changeset": "3584184",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf-icons.css",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2",
            "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2",
        ],
        "Comment": "JJF - INTEGRATE - Add icon-overview and sync core vrf-icons.css"
    },
    {
        "ID": 321,
        "Date": "9/06/2023",
        "Changeset": "3584032",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/custom.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-range-slider.html"
        ],
        "Comment": "KM - INTEGRATE - Updated range slider CSS and JS location"
    },
    {
        "ID": 322,
        "Date": "9/06/2023",
        "Changeset": "3584154",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-toasters.html"
        ],
        "Comment": "KM - IGNORE - Added copy code snippet to assets-toasters.html"
    },
    {
        "ID": 323,
        "Date": "9/06/2023",
        "Changeset": "3584292",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/custom.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/js/vrf.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-toasters.html",
        ],
        "Comment": "KM - INTEGRATE - Updated toaster component CSS and JS location"
    },
    {
        "ID": 324,
        "Date": "9/06/2023",
        "Changeset": "3584388",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "KM - IGNORE - applied updates re modal focus from VRF PSSP core"
    },
    {
        "ID": 325,
        "Date": "9/06/2023",
        "Changeset": "3584495",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-toggles.html"
        ],
        "Comment": "CD - INTEGRATE - Update copy text toggle label"
    },
    {
        "ID": 326,
        "Date": "9/06/2023",
        "Changeset": "3584535",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/js/vrf.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-filters.html"
        ],
        "Comment": "CD - INTEGRATE - Update Filters css and accessibility functionality"
    },
    {
        "ID": 327,
        "Date": "9/06/2023",
        "Changeset": "3584535",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/js/vrf.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-filters.html"
        ],
        "Comment": "CD - INTEGRATE - Update Filters css and accessibility functionality"
    },
    {
        "ID": 328,
        "Date": "9/06/2023",
        "Changeset": "3584552",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/custom.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
        ],
        "Comment": "CD - INTEGRATE - Update toggle label css to core"
    },
    {
        "ID": 329,
        "Date": "9/06/2023",
        "Changeset": "3584805",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "DS - INTEGRATE - core js clean up, moved barChartInit() to inline script"
    },
    {
        "ID": 330,
        "Date": "9/06/2023",
        "Changeset": "3584814",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "DS - INTEGRATE - core css clean up, moved startburst, radio card, bar chart, data wheel css to custom.css"
    },
    {
        "ID": 331,
        "Date": "9/06/2023",
        "Changeset": "3584818",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/custom.css"
        ],
        "Comment": "DS - INTEGRATE - moved startburst, radio card, bar chart, data wheel css from vrf.css"
    },
    {
        "ID": 332,
        "Date": "9/06/2023",
        "Changeset": "3584836",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-bar-chart.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-cards.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-data-wheel.html",
            "$/Markups/VRF/VRF-docs/virgin/brand-starburst.html"
        ],
        "Comment": "DS - IGNORE - added disclaimer text, added inline js script, added custom.css src"
    },
    {
        "ID": 333,
        "Date": "9/06/2023",
        "Changeset": "3584860",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-accordion.html"
        ],
        "Comment": "DS - IGNORE - updated accordion classes"
    },
    {
        "ID": 334,
        "Date": "9/06/2023",
        "Changeset": "3584410",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/docs.css"
        ],
        "Comment": "JJF - INTEGRATE - Added new assets-vrf-icons.html"
    },
    {
        "ID": 335,
        "Date": "9/06/2023",
        "Changeset": "3585295",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-vrf-icons.html",
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
        ],
        "Comment": "JJF - INTEGRATE - Insert assets-vrf-icons.html to the sidebar"
    },
    {
        "ID": 336,
        "Date": "9/08/2023",
        "Changeset": "3587769",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "DS - INTEGRATE - core js update for click on space delegate"
    },
    {
        "ID": 337,
        "Date": "9/08/2023",
        "Changeset": "3587774",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-accordion.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-modals.html"
        ],
        "Comment": "DS - INTEGRATE - added updated click on space classes"
    },
    {
        "ID": 338,
        "Date": "9/08/2023",
        "Changeset": "3588474",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "LR - INTEGRATE - update option click function"
    },
    {
        "ID": 339,
        "Date": "9/08/2023",
        "Changeset": "3588583",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "DS - INTEGRATE - core js update for conditional update for click on space or enter"
    },
    {
        "ID": 340,
        "Date": "9/08/2023",
        "Changeset": "3590242",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "CD - INTEGRATE - Add spacer margin top 0"
    },
    {
        "ID": 341,
        "Date": "9/09/2023",
        "Changeset": "3590116",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "LR - INTEGRATE - update combobox css focus"
    },
    {
        "ID": 342,
        "Date": "9/09/2023",
        "Changeset": "3590291",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "CD - INTEGRATE - Add spacer margin top 0"
    },
    {
        "ID": 343,
        "Date": "9/11/2023",
        "Changeset": "3593194",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "CD - INTEGRATE - Update line height .headline-medium"
    },
    {
        "ID": 344,
        "Date": "9/11/2023",
        "Changeset": "3596551",
        "File": [
            "$/Markups/VRF/VRF-docs/content/js/vrf-icons.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-vrf-icons.html"
        ],
        "Comment": "JJF - INTEGRATE - Remove project icons from vrf-icons.css core file"
    },
    {
        "ID": 345,
        "Date": "9/12/2023",
        "Changeset": "3597448",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
        ],
        "Comment": "JJF - INTEGRATE - Align PSSP vrf-icons.css to VRF-docs vrf-icons.css"
    },
    {
        "ID": 346,
        "Date": "9/12/2023",
        "Changeset": "3598926",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/docs.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-vrf-icons.html",
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
        ],
        "Comment": "JJF - INTEGRATE - Update css for vrf-docs"
    },
    {
        "ID": 347,
        "Date": "9/14/2023",
        "Changeset": "3614035",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/js/lazyload.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-lazyloader.html",
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
        ],
        "Comment": "KM - Added Custom Lazyload Vanilla JS and assets-lazyloader.html"
    },
    {
        "ID": 348,
        "Date": "9/15/2023",
        "Changeset": "3615952",
        "File": [
            "$/Markups/VRF/VRF-docs/assets/img/lazy_img"
        ],
        "Comment": "KM - IGNORE Added lazy_img assets folder"
    },
    {
        "ID": 349,
        "Date": "9/15/2023",
        "Changeset": "3615954",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/custom.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "DS - INTEGRATE - move radio card css from custom to core css"
    },
    {
        "ID": 350,
        "Date": "9/15/2023",
        "Changeset": "3615959",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "DS - INTEGRATE - updated core css functions for delagation"
    },
    {
        "ID": 351,
        "Date": "9/15/2023",
        "Changeset": "3615968",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-cards.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-checkbox-button.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-radio-button.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-terms.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-tooltips.html"
        ],
        "Comment": "DS - INTEGRATE - html class updates for core js delegation update"
    },
    {
        "ID": 352,
        "Date": "9/15/2023",
        "Changeset": "3616223",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "KM - IGNORE - Minor update in modal close button padding(mobile view)"
    },
    {
        "ID": 353,
        "Date": "9/15/2023",
        "Changeset": "3616385",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-modals.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-tooltips.html"
        ],
        "Comment": "KM - IGNORE - Minor update in modals and tooltip-modal"
    },
    {
        "ID": 354,
        "Date": "9/16/2023",
        "Changeset": "3618079",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "DS - INTEGRATE - core css update for combobox text issue"
    },
    {
        "ID": 355,
        "Date": "9/18/2023",
        "Changeset": "3622648",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-simple-footer.html"
        ],
        "Comment": "CD - INTEGRATE - Update font face poppins-semibold to poppins-regular assets-simple-footer.html"
    },
    {
        "ID": 356,
        "Date": "9/19/2023",
        "Changeset": "3624474",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "CD - INTEGRATE - Update toggle label base on styleguide update"
    },
    {
        "ID": 357,
        "Date": "9/20/2023",
        "Changeset": "3628047",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-toggles.html"
        ],
        "Comment": "CD - INTEGRATE - Updated a11y utilize HTML checked property"
    },
    {
        "ID": 358,
        "Date": "9/18/2023",
        "Changeset": "3621479",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "DS - INTEGRATE - core js update, aria-selected on combobox selected option"
    },
    {
        "ID": 359,
        "Date": "9/18/2023",
        "Changeset": "3622360",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "DS - INTEGRATE - core css update for ecare chat focus border radius"
    },
    {
        "ID": 360,
        "Date": "9/18/2023",
        "Changeset": "3623102",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "DS - INTEGRATE - core js update for radio cards descendant buttons click and focus behavior"
    },
    {
        "ID": 361,
        "Date": "9/18/2023",
        "Changeset": "3623107",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-cards.html"
        ],
        "Comment": "DS - INTEGRATE - cards html update for radio cards descendant buttons click and focus behavior"
    },
    {
        "ID": 362,
        "Date": "9/18/2023",
        "Changeset": "3622382",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-lazyloader.html"
        ],
        "Comment": "KM - IGNORE - minor update in copy-text assets-lazyloader.html"
    },
    {
        "ID": 363,
        "Date": "9/18/2023",
        "Changeset": "3623194",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-toasters.html"
        ],
        "Comment": "KM - INTEGRATE - refactor - added delegation/updated structure for toast components functions"
    },
    {
        "ID": 364,
        "Date": "9/19/2023",
        "Changeset": "3623966",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-simple-header.html"
        ],
        "Comment": "LR - INTEGRATE - update simple header components"
    },
    {
        "ID": 365,
        "Date": "9/19/2023",
        "Changeset": "3624241",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/accessibility-bookmarklet.html",
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
        ],
        "Comment": "JJF - INTEGRATE - Create Accessibility Bookmarklet page to VRF-docs"
    },
    {
        "ID": 366,
        "Date": "9/19/2023",
        "Changeset": "3624254",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "LR - INTEGRATE - update padding style for input fields"
    },
    {
        "ID": 367,
        "Date": "9/19/2023",
        "Changeset": "3625310",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "LR - INTEGRATE - added virgin.js function converted to native script"
    },
    {
        "ID": 368,
        "Date": "9/19/2023",
        "Changeset": "3626148",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-links.html"
        ],
        "Comment": "DS - INTEGRATE - core css and assets-links.html update for a11y revision"
    },
    {
        "ID": 369,
        "Date": "9/20/2023",
        "Changeset": "3627346",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-range-slider.html"
        ],
        "Comment": "KM - INTEGRATE - refactor - added delegation/updated structure for range slider components functions"
    },
    {
        "ID": 370,
        "Date": "9/20/2023",
        "Changeset": "3627625",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-prices.html"
        ],
        "Comment": "KM - IGNORE - updated a11y - Info and Relationships 1.3.1 = 's' or 'strike' tags used to format text in assets-prices.html"
    },
    {
        "ID": 371,
        "Date": "9/20/2023",
        "Changeset": "3628297",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "KM - IGNORE added border-radius: 6px on skip-link focus"
    },
    {
        "ID": 372,
        "Date": "9/20/2023",
        "Changeset": "3628473",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-alerts.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-filters.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-lazyloader.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-placeholders.html",
            "/Markups/VRF/VRF-docs/virgin/assets-scrollbar.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-skip-link.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-tables.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-tags.html"
        ],
        "Comment": "JJF - INTEGRATE - Fixed a11y issue for vrf-document pages"
    },
    {
        "ID": 373,
        "Date": "9/20/2023",
        "Changeset": "3629172",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "LR - INTEGRATE - added comment for converted function"
    },
    {
        "ID": 374,
        "Date": "9/20/2023",
        "Changeset": "3629357",
        "File": [
            "/Markups/VRF/VRF-docs/content/css/custom-icons.css",
            "$/Markups/VRF/VRF-docs/content/fonts/custom-icons.eot",
            "$/Markups/VRF/VRF-docs/content/fonts/custom-icons.svg",
            "$/Markups/VRF/VRF-docs/content/fonts/custom-icons.ttf",
            "$/Markups/VRF/VRF-docs/content/fonts/custom-icons.woff",
            "$/Markups/VRF/VRF-docs/content/fonts/custom-icons.woff2",
            "$/Markups/VRF/VRF-docs/virgin/assets-cards.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-data-wheel.html"
        ],
        "Comment": "DS - INTEGRATE - custom-icons for radio card and data wheel update"
    },
    {
        "ID": 375,
        "Date": "9/20/2023",
        "Changeset": "3631467",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "DS - IGNORE - core js update clean up"
    },
    {
        "ID": 376,
        "Date": "9/20/2023",
        "Changeset": "3631610",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "DS - IGNORE - core js latest date comment update"
    },
    {
        "ID": 377,
        "Date": "9/21/2023",
        "Changeset": "3633028",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "CD - INTEGRATE - Update table text color"
    },
    {
        "ID": 378,
        "Date": "9/21/2023",
        "Changeset": "3633554",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/custom.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-datepicker.html",
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
        ],
        "Comment": "LR - INTEGRATE - added date picker components"
    },
    {
        "ID": 379,
        "Date": "9/21/2023",
        "Changeset": "3634284",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/custom.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-datepicker.html"
        ],
        "Comment": "LR - INTEGRATE - update datepicker position style"
    },
    {
        "ID": 380,
        "Date": "9/22/2023",
        "Changeset": "3634668",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-checkbox-button.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-input-fields.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-radio-button.html"
        ],
        "Comment": "JJF - INTEGRATE - Fixed a11y issue for vrf-document Forms pages"
    },
    {
        "ID": 381,
        "Date": "9/22/2023",
        "Changeset": "3637569",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-lazyloader.html"
        ],
        "Comment": "KM - INTEGRATE added lazyload example inside accordion and modal component"
    },
    {
        "ID": 382,
        "Date": "9/22/2023",
        "Changeset": "3637651",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
        ],
        "Comment": "DS - INTEGRATE - core utilities css txt-yellow update"
    },
    {
        "ID": 383,
        "Date": "9/22/2023",
        "Changeset": "3639799",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-data-wheel.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-footer-dock.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-footer-form.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-range-slider.html"
        ],
        "Comment": "JJF - INTEGRATE - Fixed a11y issue for vrf-document pages"
    },
    {
        "ID": 384,
        "Date": "9/25/2023",
        "Changeset": "3641906",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-terms.html"
        ],
        "Comment": "CD - INTEGRATE - Fixed a11y issues for assets-terms.html"
    },
    {
        "ID": 385,
        "Date": "9/25/2023",
        "Changeset": "3643046",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-simple-footer.html"
        ],
        "Comment": "CD - INTEGRATE - Restructure the footer anchor elements, added alt text for images assets-simple-footer.html"
    },
    {
        "ID": 386,
        "Date": "9/25/2023",
        "Changeset": "3641333",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-input-fields.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-modals.html"
        ],
        "Comment": "LR - INTEGRATE - update icons size and spacing for modal and inputs fields"
    },
    {
        "ID": 387,
        "Date": "9/25/2023",
        "Changeset": "3643120",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css",
            "$/Markups/VRF/VRF-docs/virgin/brand-colors.html"
        ],
        "Comment": "JJF - INTEGRATE - Aligend vrf utilities color yellow for both Docs and Pssp core"
    },
    {
        "ID": 388,
        "Date": "9/25/2023",
        "Changeset": "3644553",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
        ],
        "Comment": "JBT - INTEGRATE - merge maverick CSS"
    },
    {
        "ID": 389,
        "Date": "9/25/2023",
        "Changeset": "3645286",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-datepicker.html"
        ],
        "Comment": "LR - INTEGRATE - update datepicker accessibility"
    },
    {
        "ID": 390,
        "Date": "9/25/2023",
        "Changeset": "3646291",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-cards.html"
        ],
        "Comment": "KM - INTEGRATE - fixed a11y issue for assets-cards.html"
    },
    {
        "ID": 391,
        "Date": "9/26/2023",
        "Changeset": "3647081",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-simple-footer.html"
        ],
        "Comment": "CD - INTEGRATE - Restructure assets-simple-footer.html and Add global-nav-connectors.css"
    },
    {
        "ID": 392,
        "Date": "9/27/2023",
        "Changeset": "3649848",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-bar-chart.html"
        ],
        "Comment": "LR - INTEGRATE - update bar chart accessibility"
    },
    {
        "ID": 393,
        "Date": "9/27/2023",
        "Changeset": "3649920",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-bar-chart.html"
        ],
        "Comment": "DS - INTEGRATE - assets-bar-chart component delegation"
    },
    {
        "ID": 394,
        "Date": "9/27/2023",
        "Changeset": "3650800",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-prices.html"
        ],
        "Comment": "KM - INTEGRATE - updated assets-prices line-height"
    },
    {
        "ID": 395,
        "Date": "9/28/2023",
        "Changeset": "3656712",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "CD - INTEGRATE - Update focus on close button width 2px radius 3px"
    },
    {
        "ID": 396,
        "Date": "9/28/2023",
        "Changeset": "3654713",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/custom.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-datepicker.html"
        ],
        "Comment": "LR - INTEGRATE - added disabled future date and update datepicker behaviour"
    },
    {
        "ID": 397,
        "Date": "9/28/2023",
        "Changeset": "3655754",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "LR - INTEGRATE - update input fields style for longtext"
    },
    {
        "ID": 398,
        "Date": "9/28/2023",
        "Changeset": "3656482",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-buttons.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-links.html"
        ],
        "Comment": "JJF - INTEGRATE - Fixed accessibility '.disabled ' class for buttons & a tags"
    },
    {
        "ID": 399,
        "Date": "9/28/2023",
        "Changeset": "3656784",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "LR - INTEGRATE - update input date fields css"
    },
    {
        "ID": 400,
        "Date": "9/29/2023",
        "Changeset": "3659877",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-input-fields.html"
        ],
        "Comment": "CD - INTEGRATE - Update carret size from 14x14 to 12x12"
    },
    {
        "ID": 401,
        "Date": "9/30/2023",
        "Changeset": "3659201",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "DS - INTEGRATE - core css clean up update for skip-link"
    },
    {
        "ID": 402,
        "Date": "9/30/2023",
        "Changeset": "3659127",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/custom.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-data-wheel.html"
        ],
        "Comment": "DS - INTEGRATE - data-wheel font-size, a11y reading issue fixed"
    },
    {
        "ID": 403,
        "Date": "9/30/2023",
        "Changeset": "3659299",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/global-navigation.css",
            "$/Markups/VRF/VRF-docs/core/js/global-navigation.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-global-nav.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-global-nav-V2.html",
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
        ],
        "Comment": "KM - INTEGRATE - initial check in for global nav component"
    },
    {
        "ID": 404,
        "Date": "10/2/2023",
        "Changeset": "3662618",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-simple-footer.html"
        ],
        "Comment": "CD - INTEGRATE - Added minimal footer assets-simple-footer.html"
    },
    {
        "ID": 405,
        "Date": "10/2/2023",
        "Changeset": "3662462",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css",
        ],
        "Comment": "JJF - INTEGRATE - Add global footer social media icons"
    },
    {
        "ID": 406,
        "Date": "10/2/2023",
        "Changeset": "3662482",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
        ],
        "Comment": "LR - INTEGRATE - update focus outline for inputs fields"
    },
    {
        "ID": 407,
        "Date": "10/2/2023",
        "Changeset": "3662529",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
        ],
        "Comment": "DS - INTEGRATE - core css update for skip-link"
    },
    {
        "ID": 408,
        "Date": "10/3/2023",
        "Changeset": "3663124",
        "File": [
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
        ],
        "Comment": "JJF - INTEGRATE - Add global footer social media to icons library"
    },
    {
        "ID": 409,
        "Date": "10/3/2023",
        "Changeset": "3663128",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css",
        ],
        "Comment": "JJF - INTEGRATE - Add Youtube icon to vrf-icons library"
    },
    {
        "ID": 410,
        "Date": "10/3/2023",
        "Changeset": "3663175",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-large-desktop-layouts.html",
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
        ],
        "Comment": "JJF - INTEGRATE - Create large desktop layouts"
    },
    {
        "ID": 411,
        "Date": "10/3/2023",
        "Changeset": "3663182",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css"
        ],
        "Comment": "JJF - INTEGRATE - sync vrf utilities core to PSSP core file"
    },
    {
        "ID": 412,
        "Date": "10/3/2023",
        "Changeset": "3663351",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf-icons.css",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2"
        ],
        "Comment": "JJF - INTEGRATE - sync vrf-icons core to PSSP core file"
    },
    {
        "ID": 413,
        "Date": "10/3/2023",
        "Changeset": "3663351",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-modals.html"
        ],
        "Comment": "DS - INTEGRATE - assets-modal and core css update for timeout modal"
    },
    {
        "ID": 414,
        "Date": "10/3/2023",
        "Changeset": "3664045",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-input-fields.html"
        ],
        "Comment": "LR - INTEGRATE - added close icon and update outline, search input style"
    },
    {
        "ID": 415,
        "Date": "10/3/2023",
        "Changeset": "3664218",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/vrf-layout-breakpoints.html"
        ],
        "Comment": "JJF - INTEGRATE - Fix vrf-layout-breakpoints.html table headers bg-color"
    },
    {
        "ID": 416,
        "Date": "10/3/2023",
        "Changeset": "3664226",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "DS - INTEGRATE - core css and html update for download buttons on assets-links"
    },
    {
        "ID": 417,
        "Date": "10/3/2023",
        "Changeset": "3664279",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/global-navigation.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf-utilities.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-footer-big.html"
        ],
        "Comment": "KM - INTEGRATE - Added assets-footer-big.html"
    },
    {
        "ID": 418,
        "Date": "10/3/2023",
        "Changeset": "3665547",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/global-navigation.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-global-nav-V2.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-global-nav.html"
        ],
        "Comment": "KM - IGNORE - updated assets-global-nav components"
    },
    {
        "ID": 419,
        "Date": "10/3/2023",
        "Changeset": "3665726",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf-icons.css",
            "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css"
        ],
        "Comment": "JJF - INTEGRATE -Rename icon-User-smile"
    },
    {
        "ID": 420,
        "Date": "10/3/2023",
        "Changeset": "3663332",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html",
            "$/Markups/VRF/VRF-docs/custom/css/global-nav-connectors.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-breadcrumbs.html",
        ],
        "Comment": "CD - INTEGRATE - Add Breadcrumbs assets-breadcrumbs.html"
    },
    {
        "ID": 421,
        "Date": "10/3/2023",
        "Changeset": "3663786",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-simple-footer.html",
        ],
        "Comment": "CD - INTEGRATE - Remove big footer assets-simple-footer.html"
    },
    {
        "ID": 422,
        "Date": "10/3/2023",
        "Changeset": "3665594",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-footer-dock.html",
        ],
        "Comment": "CD - INTEGRATE - Fix dock bar responsive and update styleguide changes"
    },
    {
        "ID": 423,
        "Date": "10/4/2023",
        "Changeset": "3667351",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-breadcrumbs.html",
        ],
        "Comment": "CD - INTEGRATE - Fixed a11y issues breadcrumbs"
    },
    {
        "ID": 424,
        "Date": "10/4/2023",
        "Changeset": "3667433",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-breadcrumbs.html",
            "$/Markups/VRF/VRF-docs/custom/global-nav-connectors.css",
        ],
        "Comment": "CD - INTEGRATE - Fixed a11y issues breadcrumbs"
    },
    {
        "ID": 425,
        "Date": "10/4/2023",
        "Changeset": "3666516",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/custom.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-datepicker.html",
        ],
        "Comment": "LR - INTEGRATE - added different position variant of calender on desktop viewport and update css, datepicker js"
    },
    {
        "ID": 426,
        "Date": "10/4/2023",
        "Changeset": "3666720",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-toasters.html",
        ],
        "Comment": "KM - IGNORE - minor fix for toaster component a11y violations"
    },
    {
        "ID": 427,
        "Date": "10/4/2023",
        "Changeset": "3667099",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/brf-tools-design.html",
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
        ],
        "Comment": "JJF - INTEGRATE - Fixed minor issue"
    },
    {
        "ID": 428,
        "Date": "10/4/2023",
        "Changeset": "3667598",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/global-nav-connectors.css"
        ],
        "Comment": "CD - INTEGRATE - Fix breadcrumbs alignment"
    },
    {
        "ID": 429,
        "Date": "10/4/2023",
        "Changeset": "3668257",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf-icons.css",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.eot",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.svg",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.ttf",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff",
            "$/Markups/VRF/Dev/PSSP/core/fonts/vrf-icons.woff2",
            "$/Markups/VRF/VRF-docs/core/css/vrf-icons.css",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.eot",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.svg",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.ttf",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff",
            "$/Markups/VRF/VRF-docs/core/fonts/vrf-icons.woff2"
        ],
        "Comment": "JJF - INTEGRATE - Add cart icon and sync vrf-icons core to PSSP core file"
    },
    {
        "ID": 430,
        "Date": "10/5/2023",
        "Changeset": "3671675",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/vrf-about.css",
            "$/Markups/VRF/VRF-docs/virgin/vrf-performance.css",
            "$/Markups/VRF/VRF-docs/virgin/vrf-strategies.css",
            "$/Markups/VRF/VRF-docs/virgin/vrf-supported-browsers.css",
        ],
        "Comment": "CD - INTEGRATE - Update Virgin logo on Guidelines pages"
    },
    {
        "ID": 431,
        "Date": "10/5/2023",
        "Changeset": "3671778",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-step-flow.html",
        ],
        "Comment": "KM - IGNORE updated step flow component structure"
    },
    {
        "ID": 432,
        "Date": "10/5/2023",
        "Changeset": "3671808",
        "File": [
            "$/Markups/VRF/Dev/PSSP/core/css/vrf-utilities.css",
            "$/Markups/VRF/Dev/PSSP/core/css/vrf.css",
        ],
        "Comment": "KM - INTEGRATE - sync vrf.css and utilities.css core to PSSP core files"
    },
    {
        "ID": 433,
        "Date": "10/5/2023",
        "Changeset": "3671884",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/core/js/vrf.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-input-fields.html",
        ],
        "Comment": "LR - INTEGRATE - added function by show/hide of search close icon"
    },
    {
        "ID": 434,
        "Date": "10/5/2023",
        "Changeset": "3671973",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/global-navigation.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-shop-nav.html",
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html",
        ],
        "Comment": "DS - INTEGRATE - added shop navigation"
    },
    {
        "ID": 435,
        "Date": "10/6/2023",
        "Changeset": "3672632",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/global-nav-connectors.css"
        ],
        "Comment": "CD - INTEGRATE - Update red breadcrumbs focus"
    },
    {
        "ID": 436,
        "Date": "10/6/2023",
        "Changeset": "3672638",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/vrf-toggle-on-off-switch.html"
        ],
        "Comment": "BFS - IGNORE - Fixed the wrong spelling words in the toggle on off switch"
    },
    {
        "ID": 437,
        "Date": "10/6/2023",
        "Changeset": "3672781",
        "File": [
            "$/Markups/VRF/VRF-docs/assets/img/carousel/crave_600x344.jpg",
            "$/Markups/VRF/VRF-docs/assets/img/carousel/crave_with_starz_600x344.jpg",
            "$/Markups/VRF/VRF-docs/assets/img/carousel/crave_with_starz_superchannel_600x344.jpg",
            "$/Markups/VRF/VRF-docs/content/css/custom.css",
            "$/Markups/VRF/VRF-docs/content/js/splide-carousel.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-carousel.html",
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html"

        ],
        "Comment": "KM- INTEGRATE - added Splide carousel component"
    },
    {
        "ID": 438,
        "Date": "10/6/2023",
        "Changeset": "3672763",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/global-navigation.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-shop-nav.html"
        ],
        "Comment": "DS - INTEGRATE - a11y reading update, minor html and css updates"
    },
    {
        "ID": 439,
        "Date": "10/6/2023",
        "Changeset": "3672832",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-step-flow.html"
        ],
        "Comment": "CD - INTEGRATE - Update focus outline white for white colored element (step flow and tabs)"
    },
    {
        "ID": 440,
        "Date": "10/6/2023",
        "Changeset": "3673044",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/vrf-toggle-on-off-switch.html"
        ],
        "Comment": "BFS - INTEGRATE - Updated toggel on off switch for source control changes"
    },
    {
        "ID": 441,
        "Date": "10/6/2023",
        "Changeset": "3673156",
        "File": [
            "$/Markups/VRF/VRF-docs/Accordian.html",
            "$/Markups/VRF/VRF-docs/brf-accessibility-articles.html",
            "$/Markups/VRF/VRF-docs/brf-accessibility-resources.html",
            "$/Markups/VRF/VRF-docs/brf-changelog.html",
            "$/Markups/VRF/VRF-docs/brf-deque-accessibility-notes.html",
            "$/Markups/VRF/VRF-docs/brf-good-practices.html",
            "$/Markups/VRF/VRF-docs/brf-layout-bootstrap-grid.html",
            "$/Markups/VRF/VRF-docs/brf-layout-breakpoints.html",
            "$/Markups/VRF/VRF-docs/brf-layout-photoshop-grid.html",
            "$/Markups/VRF/VRF-docs/brf-nav.html",
            "$/Markups/VRF/VRF-docs/brf-performance.html",
            "$/Markups/VRF/VRF-docs/brf-sidebar-nav.html",
            "$/Markups/VRF/VRF-docs/brf-strategies.html",
            "$/Markups/VRF/VRF-docs/brf-supported-browsers.html",
            "$/Markups/VRF/VRF-docs/brf-tools-accessibility.html",
            "$/Markups/VRF/VRF-docs/brf-tools-design.html",
            "$/Markups/VRF/VRF-docs/brf-tools-responsive.html",
            "$/Markups/VRF/VRF-docs/BRF3 Migration Update Document.docx",
            "$/Markups/VRF/VRF-docs/nav-topFederal.html",
            "$/Markups/VRF/VRF-docs/what-is-brf.html"
        ],
        "Comment": "BFS - IGNORE - deleted uncesseary files from old copied brf framework"
    },
    {
        "ID": 442,
        "Date": "10/6/2023",
        "Changeset": "3673170",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-buttons.html"
        ],
        "Comment": "DS - IGNORE - html update for assets-buttons"
    },
    {
        "ID": 443,
        "Date": "10/6/2023",
        "Changeset": "3673044",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/vrf-toggle-on-off-switch.html"
        ],
        "Comment": "BFS - INTEGRATE - Updated toggel on off switch for source control changes"
    },
    {
        "ID": 444,
        "Date": "10/6/2023",
        "Changeset": "3673236",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/shop-navigation.css",
            "$/Markups/VRF/VRF-docs/core/css/global-navigation.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-shop-nav.html"
        ],
        "Comment": "DS - IGNORE - created separate css for assets-shop-nav"
    },
    {
        "ID": 445,
        "Date": "10/6/2023",
        "Changeset": "3673252",
        "File": [
            "$/Markups/VRF/VRF-docs/html/accordion.html",
            "$/Markups/VRF/VRF-docs/html/alert-messages.html",
            "$/Markups/VRF/VRF-docs/html/anchors.html",
            "$/Markups/VRF/VRF-docs/html/asset-icons.html",
            "$/Markups/VRF/VRF-docs/html/bar-chart.html",
            "$/Markups/VRF/VRF-docs/html/buttons.html",
            "$/Markups/VRF/VRF-docs/html/card.html",
            "$/Markups/VRF/VRF-docs/html/colours.html",
            "$/Markups/VRF/VRF-docs/html/effect-style.html",
            "$/Markups/VRF/VRF-docs/html/global-nav.html",
            "$/Markups/VRF/VRF-docs/html/grids.html",
            "$/Markups/VRF/VRF-docs/html/input-fields.html",
            "$/Markups/VRF/VRF-docs/html/links.html",
            "$/Markups/VRF/VRF-docs/html/logo.html",
            "$/Markups/VRF/VRF-docs/html/plus-up.html",
            "$/Markups/VRF/VRF-docs/html/skip-link.html",
            "$/Markups/VRF/VRF-docs/html/starburst.html",
            "$/Markups/VRF/VRF-docs/html/tags.html",
            "$/Markups/VRF/VRF-docs/html/typography.html",
            "$/Markups/VRF/VRF-docs/virgin/resources-tools-design.html"

        ],
        "Comment": "BFS - IGNORE - deleted old html files used from pssp and added fix for the icon missing in responsive tools"
    },
    {
        "ID": 446,
        "Date": "10/9/2023",
        "Changeset": "3675702",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/global-navigation.css"
        ],
        "Comment": "KM - IGNORE - override pseudo :before color for footer icon-pin-location"
    },
    {
        "ID": 447,
        "Date": "10/9/2023",
        "Changeset": "3675995",
        "File": [
            "$/Markups/VRF/VRF-docs/core/css/vrf.css"
        ],
        "Comment": "DS - INTEGRATE - core css update for link-small hover/focus fix"
    },
    {
        "ID": 448,
        "Date": "10/10/2023",
        "Changeset": "3676814",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/assets-global-nav-V2.html",
            "$/Markups/VRF/VRF-docs/virgin/assets-global-nav.html"
        ],
        "Comment": "JJF - INTEGRATE - fixed a11y missing aria-current"
    },
    {
        "ID": 449,
        "Date": "10/10/2023",
        "Changeset": "3678062",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/shop-navigation.css",
            "$/Markups/VRF/VRF-docs/content/js/shop-navigation.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-shop-nav.html"
        ],
        "Comment": "DS - INTEGRATE - assets-shop-nav structure update, css and js update"
    },
    {
        "ID": 450,
        "Date": "10/11/2023",
        "Changeset": "3679084",
        "File": [
            "$/Markups/VRF/VRF-docs/documents/How_to_Setup_your_Local_Development_Environment__(Virgin&Bell).pdf",
            "$/Markups/VRF/VRF-docs/virgin/resources-local-set-up-env.html",
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html",
        ],
        "Comment": "BFS - INTEGRATE - Added a generalized local set up environment in the docs"
    },
    {
        "ID": 450,
        "Date": "10/11/2023",
        "Changeset": "3679100",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
        ],
        "Comment": "BFS - Removed target blank in the newly added set up of local env steps"
    },
    {
        "ID": 451,
        "Date": "10/11/2023",
        "Changeset": "3679118",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/vrf-toggle-on-off-switch.html"
        ],
        "Comment": "BFS - INTEGRATE - Updated toggle on off switch source folder changes and"
    },
    {
        "ID": 452,
        "Date": "10/11/2023",
        "Changeset": "3679409",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/vrf-supported-browsers.html"
        ],
        "Comment": "CD - INTEGRATE - Update supported browser versions and release date"
    },
    {
        "ID": 453,
        "Date": "10/11/2023",
        "Changeset": "3679741",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/shop-navigation.css",
            "$/Markups/VRF/VRF-docs/content/js/shop-navigation.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-shop-nav.html"
        ],
        "Comment": "DS - INTEGRATE - assets-shop-nav updated for a11y fixes"
    },
    {
        "ID": 454,
        "Date": "10/11/2023",
        "Changeset": "3679760",
        "File": [
            "$/Markups/VRF/VRF-docs/content/js/shop-navigation.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-shop-nav.html"
        ],
        "Comment": "DS - INTEGRATE - assets-shop-nav js update for breadcrumbs a11y"
    },
    {
        "ID": 455,
        "Date": "10/11/2023",
        "Changeset": "3679873",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/custom.css",
            "$/Markups/VRF/VRF-docs/content/js/splide-carousel.js",
            "$/Markups/VRF/VRF-docs/virgin/assets-carousel.html"
        ],
        "Comment": "KM - INTEGRATE - Added Splide Play-Pause Toggle component"
    },
    {
        "ID": 456,
        "Date": "10/11/2023",
        "Changeset": "3680231",
        "File": [
            "$/Markups/VRF/VRF-docs/core/js/vrf.js"
        ],
        "Comment": "DS - INTEGRATE - core js update for accordion fix"
    },
    {
        "ID": 457,
        "Date": "10/12/2023",
        "Changeset": "3681920",
        "File": [
            "$/Markups/VRF/VRF-docs/virgin/brand-style-guide.html"
        ],
        "Comment": "BFS - INTEGRATE - Modify the style guide content in the documentation"
    },
    {
        "ID": 458,
        "Date": "10/12/2023",
        "Changeset": "3682164",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/custom.css"
        ],
        "Comment": "KM - IGNORE - remove Splide play-pause toggle button stroke"
    },
    {
        "ID": 459,
        "Date": "10/12/2023",
        "Changeset": "3682375",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/shop-navigation.css"
        ],
        "Comment": "DS - IGNORE - font file path update"
    },
    {
        "ID": 460,
        "Date": "10/12/2023",
        "Changeset": "3682552",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/shop-navigation.css"
        ],
        "Comment": "CD - INTEGRATE - Update data wheel changed to figure"
    },
    {
        "ID": 461,
        "Date": "10/14/2023",
        "Changeset": "3682552",
        "File": [
            "$/Markups/VRF/VRF-docs/content/js/project-pssp.json",
            "$/Markups/VRF/VRF-docs/virgin/project-pssp-file.html",
            "$/Markups/VRF/VRF-docs/virgin/sidebar.html"
        ],
        "Comment": "JJF - INTEGRATE - Add Project Tab to VRF1 Document"
    },
    {
        "ID": 462,
        "Date": "10/14/2023",
        "Changeset": "3684613",
        "File": [
            "$/Markups/VRF/VRF-docs/content/css/custom.css",
            "$/Markups/VRF/VRF-docs/virgin/assets-data-wheel.html"
        ],
        "Comment": "CD - INTEGRATE - Update properties to r=19 assets-data-wheel.html"
    }
]