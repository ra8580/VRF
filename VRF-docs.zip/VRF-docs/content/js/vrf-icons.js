const iconRunner = {
    //global val
    _sideListTargetClass: '.lstg_projIconsList',
    _targetDOMIconListClass: '.olListIcons',
    _tb_id_searchbox: '#search_icons',

    //store all cssstyle Rules with key of button id
    __stylesList: new Map(),
    __searchedKey: '',

    //init function for the icon loader
    loadTheIconsInit: function () {
        // //read the link stylesheets attached to the [page]
        // //// read the icon file added to page and populate the icons from it 
        let cssIconresult = this.readAttachedStylesheets();
        // this.readAttachedStylesheets();

        if (cssIconresult.length > 0) { 
            this.addProjectNamesToSideBar(cssIconresult, this._sideListTargetClass, this._targetDOMIconListClass);

            this.initSearch(this._tb_id_searchbox);

        } else {
            document.querySelector(this._sideListTargetClass).css("color", "red").text("Please add css file link in HTML head");
            console.log('Error')
        }
        console.log('loadTheIconsInit');
    },
    //read the attached stylesheet from the page and populate the list
    readAttachedStylesheets: function() {
        //array storing the file names for the icons
        const iconsFilesInDom = [];

        console.log('readAttachedStylesheets');

        let headContent = document.querySelector('head').children;
        if(headContent) {
            console.log(headContent);
            for (var _i = 0; _i < headContent.length; _i++) {
                let ele = headContent[_i];
                if (ele.nodeName === 'LINK') {
                    console.log(ele.nodeName);
                    if (("" + ele.href).indexOf('-icons.css') >= 0 || ("" + ele.href).indexOf('-icon.css') >= 0) {
                        const path_arr = ele.href.split('/');

                        let $ele = ele;
                        console.log($ele.sheet.rules);
                        //check for data-cname attribute that indicate the classname of the new set of icons
                        var iconname = ele.dataset.cname;


                        //for IE and Chrome
                        if ($ele.sheet) {
                            iconsFilesInDom.push({
                                name: path_arr[path_arr.indexOf("Dev") + 1], fpath: path_arr[path_arr.length - 1],
                                size: $ele.sheet.rules.length, styleRules: $ele.sheet.rules, cname: iconname
                            });
                        }
                        else {
                            //FIREFOX IF SHEET IS NULL
                            for (var _j = 0; _j < (headContent.length - 1); _j++) {
                                var targetElem = headContent[_j].nextElementSibling;
                                var targetElemSheet = headContent[_j].nextElementSibling.sheet;
                                if (targetElem.nodeName === "LINK") {
                                    // get icon file added by link other wise comment this out 
                                    if (("" + targetElem.href).indexOf('-icons.css') >= 0 || ("" + targetElem.href).indexOf('-icon.css') >= 0) {
                                        const path_array = targetElem.href.split('/'); 
                                    
                                        if (targetElemSheet) {
                                            iconsFilesInDom.push({
                                                name: path_array[path_array.indexOf("Dev") + 1], fpath: path_array[path_array.length - 1],
                                                size: targetElemSheet.rules.length, styleRules: targetElemSheet.rules, cname: iconname
                                            });
                                        } 
                                    }
                                }
                            }

                            break;
                        }

                    }
                }

            }
        }

        return iconsFilesInDom;
    },

    //funcation to add project names to the list
    addProjectNamesToSideBar: function (iconsFilesInDom, _sideListTargetClass, _iconTargetListClassName) {
        //if there any icon files attached iterate through them
        if (iconsFilesInDom.length > 0) {
            let _index = 0;
            for (let i = 0; i < iconsFilesInDom.length; i++) {
                let list = iconsFilesInDom[i];
                let _item_btn = document.createElement('button');
                let _val_btn_id = 'btn_' + _index;
                _item_btn.id = _val_btn_id;
                _item_btn.classList.add("list-group-item", "list-group-item-action", "d-flex", "justify-content-between", "align-items-center");
                _item_btn.textContent = list.cname;
                
                _item_btn.setAttribute('data-target-icon-list', _iconTargetListClassName);
                _item_btn.setAttribute('data-fPath', list.fpath);
                _item_btn.setAttribute('onClick', "iconRunner.loadSelectedIconsOnPage(this.id)")
                //create data-cname attribute if declared in the css reference using data-cname attribute
                if (list.cname != undefined) {
                    _item_btn.setAttribute('data-cname', list.cname);
                }

                let _item_span_size = document.createElement("span");
                _item_span_size.classList.add("badge");
                _item_span_size.classList.add("badge-primary");
                _item_span_size.classList.add("badge-pill");
                _item_span_size.textContent = list.size;
                _item_btn.appendChild(_item_span_size);

                document.querySelector(_sideListTargetClass).append(_item_btn);

                //add the cssRule list object to the stylelist to retrieve on click
                this.__stylesList.set(_val_btn_id, list.styleRules);

                _index++;
            }
        }
    },

    //trigger event on side bar button click to show only the selected file icons
    loadSelectedIconsOnPage: function (_btn_id) {
        const $_btn_id_query = document.querySelector(`#${_btn_id}`);

        let filename = $_btn_id_query.getAttribute("data-fpath");

        let disabledLink = document.querySelectorAll(`link[href*="-icons.css`);
        for (let i = 0; i < disabledLink.length; i++) {
            disabledLink[i].disabled = true;
        }

        let enableLink = document.querySelectorAll(`link[href$='${filename}']`);
        for (let j = 0; j < enableLink.length; j++) {
            enableLink[j].disabled = false;
        }

        if (!$_btn_id_query.classList.contains('active')) {
            let activeClassList = document.querySelectorAll(`.active:not(#${_btn_id})`);

            activeClassList.forEach(function(active) {
                active.classList.remove('active');
            });
            
            $_btn_id_query.classList.toggle('active');
        }

        ////pass the class name to be use for the icon if declared 
        let cname = $_btn_id_query.getAttribute('data-cname');

        console.log(this.__stylesList.has(_btn_id)); 
        if (this.__stylesList.has(_btn_id)) {
           this.fxIconLoaderFromList(this.__stylesList.get(_btn_id), $_btn_id_query.getAttribute("data-target-icon-list"), 
               cname);

           //trigger search filter if the search text is already there
           if (this.__searchedKey.length > 0) {
               this.filterTheIconList(this.__searchedKey);
           }
        }
    },

    loadIconsCssFromList: function (cssRuleList) {
        const _cssRulesClassStringList = [];
        //iterate over the cssRule list
        for (var i = 0; i < cssRuleList.length; i++) {
            const iconClasses = cssRuleList[i];
            // filtering only css styles
            //for chrome and new browsers
            if ("" + iconClasses.__proto__.constructor.name === 'CSSStyleRule') {
                // check for the lement which may contain after or before colons
                const iconselectortext = iconClasses.selectorText;
                const cssStyleDeclaration = iconClasses.style;
                if (iconselectortext.indexOf('::') >= 0) {

                    //check if the cssStyleDeclaration contains "content"
                    if (Object.values(cssStyleDeclaration).indexOf('content') !== -1) {
                        _cssRulesClassStringList.push(iconselectortext);
                    }
                    //check if the  cssStyleDeclaration contains "transform"
                    else if (Object.values(cssStyleDeclaration).indexOf('transform') !== -1) {
                        _cssRulesClassStringList.push(iconselectortext);
                    }
                }
            }
            //for iE 
            else if (iconClasses.selectorText) {
                if (iconClasses.selectorText.indexOf("::") >= 0) {
                    const iconselectortext = iconClasses.selectorText;
                    const cssStyleDeclaration = iconClasses.style;

                    //check if the cssStyleDeclaration contains "content"
                    if (Object.values(cssStyleDeclaration).indexOf('content') !== -1) {
                        _cssRulesClassStringList.push(iconselectortext);
                    }
                    //check if the  cssStyleDeclaration contains "transform"
                    else if (Object.values(cssStyleDeclaration).indexOf('transform') !== -1) {
                        _cssRulesClassStringList.push(iconselectortext);
                    }
                }
            }
        }
        return _cssRulesClassStringList;
    },

     ////function to be called on on click if the  button has styles in it
     fxIconLoaderFromList: function (_listOfClasses, _targetIconDOMListClass, cname) {
        var cssStyleList = this.loadIconsCssFromList(_listOfClasses);
        if (cssStyleList.length > 0) {

            const cleanCssNamesArr = [];
            //filter for classes contain font family declaration as icons donot have them individually  
            for (var i = 0; i < cssStyleList.length; i++) {
                const iconcontent = cssStyleList[i];

                //const _targetDOMListClass = '.olListIcons';
                const cssclassNameClean = this.buildclassNamesFromRules(iconcontent);
                cleanCssNamesArr.push.apply(cleanCssNamesArr, cssclassNameClean);
            }

            const _iconLoadedSuccess = this.loadIconsClassesFromArr(cleanCssNamesArr, _targetIconDOMListClass, cname);
        }
    },

    //// get the class name for icons
    buildclassNamesFromRules: function (iconSelectorText) {
        const iconClassName = [];
        //check if there are multiple class declarations
        if (iconSelectorText.indexOf(",") >= 0) {
            const iconMultipleClasses = iconSelectorText.split(',');
            // Loop for multiple classes
            for (var i = 0; i < iconMultipleClasses.length; i++) {
                const singleIconClassText = iconMultipleClasses[i];
                iconClassName.push(this.getIconClassNameFromRule(singleIconClassText.trim()));
            }
        } else {
            //for single class declaration get the icon class name
            iconClassName.push(this.getIconClassNameFromRule(iconSelectorText));
            //console.log(getIconClassNameFromRule(iconSelectorText));  
        }
        return iconClassName;
    },

    //split the icon css rule to remove ::before
    getIconClassNameFromRule: function (_iconClassName) {
        if (_iconClassName.indexOf("::") >= 0) {
            const iconnameArr = _iconClassName.split('::');
            return iconnameArr[0].replace('.', '');
        }
        return _iconClassName;
    },
    //add icon class names to the DOM container
    loadIconsClassesFromArr: function (_cleanCssNamesArr, _targetDOMListClass, cname){

        let emptyElem = document.querySelector(_targetDOMListClass);
        emptyElem.innerHTML = '';

        for (let i = 0; i < _cleanCssNamesArr.length; i++) {
            //create the list item
            const elemCreatedToAdd = this.createListItemFromClassName(_cleanCssNamesArr[i], cname);

            if (elemCreatedToAdd !== null) {
                console.log('append div icons');
                document.querySelector(_targetDOMListClass).append(elemCreatedToAdd);
            }
        }
       
        return false;
    }, 

    //// add icon content to the list
    createListItemFromClassName: function (_cssClassName, cname) {
        //set class name to be use if declare else use default icon
        var firstclassname = cname != undefined ? cname : "icon"
        var _item_btn = document.createElement('div');
        _item_btn.tabIndex = 0;
        _item_btn.classList.add("iconListItem");
        _item_btn.classList.add("card");
        _item_btn.classList.add("pad-20");
        _item_btn.classList.add("txtSize30");
    

        var _item_span_first = document.createElement("span");
        var _item_div_cname = document.createElement("div")

        // //check if multi icon
        if (_cssClassName.indexOf(" ") > 0) {

            console.log('multi-color icon');

            // const iconnameArr = _cssClassName.split(' ');
            // const iconParent = iconnameArr[0].replace('.', ' ');
            // const multiPath = iconnameArr[1].replace('.', '');

        } else {
            const iconnameArr = _cssClassName.split('.');

            if(iconnameArr.length > 1) {
                _item_span_first.classList.add("icon");
                _item_span_first.classList.add(firstclassname);
                _item_span_first.classList.add(iconnameArr[0]);
                _item_span_first.classList.add(iconnameArr[1]);
                console.log(_cssClassName);
                _item_div_cname.classList.add("copy-medium-bold", "pad-t-15");
                _item_div_cname.textContent = iconnameArr[1];

                _item_btn.appendChild(_item_span_first);
                _item_btn.appendChild(_item_div_cname);
            } else {
                _item_span_first.classList.add("icon");
                _item_span_first.classList.add(firstclassname);
                _item_span_first.classList.add(iconnameArr[0]);
                console.log(_cssClassName);
                _item_div_cname.classList.add("copy-medium-bold", "pad-t-15");
                _item_div_cname.textContent = iconnameArr[0];

                _item_btn.appendChild(_item_span_first);
                _item_btn.appendChild(_item_div_cname);
            }
        }

        return _item_btn; 
    },

    //function to filter the icon list based on the keywords
    initSearch: function (_searchTextId) {
        //search filter for icons
        const $_searchtextInput = document.querySelector(_searchTextId);

        $_searchtextInput.addEventListener('keyup', function(e) {
            console.log(e.target.value);
            let value = $_searchtextInput.value.toLowerCase();
            //setting the searched key globally
            iconRunner.__searchedKey = value;
            iconRunner.filterTheIconList(value);
        });
    },

    filterTheIconList: function (_searchedValue) {
        var iconList = document.querySelectorAll(".olListIcons .iconListItem");
        
        iconList.forEach(function(item) {
            var span = item.children[0];
            if (span && span.classList.contains("icon")) {
                var spanClassName = span.className.replace("icon ", "");
                item.style.display = spanClassName.toLowerCase().indexOf(_searchedValue) > -1 ? "block" : "none";
            }
        });
    }
    

};

iconRunner.loadTheIconsInit();

