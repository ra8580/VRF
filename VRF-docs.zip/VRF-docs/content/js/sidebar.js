// $(document).ready(function () {
   
//     var parent_links = [], l = $('div.sidebar-submenu');
//     for (var i = 0; i < l.length; i++) {
//         parent_links.push(l[i].href);
//     }
//     console.log(parent_links);

//     var link = document.URL;
//     console.log(link);
//     var divided_link = link.split("/");
//     var html_name = divided_link[(divided_link.length - 1)].split("/");
//     var name = html_name[0];
//     var sub_html_name = html_name[0].split(".");
//     var sub_html_name = sub_html_name[0].split("-");
//     var parent_link = sub_html_name[0];
//     var child_link = sub_html_name[1];
//     var active_parent_link = $('#' + parent_link + '-submenu');

//     // for parent menu
//     active_parent_link.addClass('show');

//     // for child-parent submenu active
//     if ($('a[href="' + name + '"]').parent('.sidebar-submenu').length) {
//         $('a[href="' + name + '"]').parent('.sidebar-submenu').addClass('show');
//         $('a[href="' + name + '"]').removeClass('text-white').addClass('text-dark');
//     } else {
//         $('a[href="' + name + '"]').removeClass('text-white').addClass('text-dark');
//     }

//     // for child
//     $('a[href="' + name + '"]').removeClass('bg-dark').addClass('bgWhite');
//     $('a[href="' + name + '"]').removeClass('bg-dark').addClass('bg-light');
//     $('a[href="' + name + '"]').addClass('rounded-0');
//     $('a[href="' + name + '"]').addClass('txtBold');

//     console.log('test');
    
// });

const sidebarFunction = () => {
    var link = document.URL;
    var divided_link = link.split("/");
    var html_name = divided_link[(divided_link.length - 1)].split("/");
    console.log(html_name);
    var name = html_name[0];
    var sub_html_name = html_name[0].split(".");
    var sub_html_name = sub_html_name[0].split("-");
    var parent_link = sub_html_name[0];
    console.log(parent_link);
    var child_link = sub_html_name[1];
    console.log(child_link);
    var active_parent_link = document.querySelector('#brand-submenu');
    console.log(active_parent_link);
    // for parent menu  
    // active_parent_link.classList.add('show');
}

document.addEventListener("DOMContentLoaded", () => {
    sidebarFunction();
});