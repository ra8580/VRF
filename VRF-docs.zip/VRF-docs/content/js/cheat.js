$(function() {

    $('.btn-clipboard').on('click', function(){

        var $this = $(this);

        $('.btn-clipboard').each(function(){
            $(this).removeClass('btn-clipboard-hover');
        });

        $this.addClass('btn-clipboard-hover');

        var id = $this.parent().next().find('pre code').attr('id');

		var el = document.getElementById(id);
		var range = document.createRange();
		range.selectNodeContents(el);
		var sel = window.getSelection();
		sel.removeAllRanges();
		sel.addRange(range);
		document.execCommand('copy');

    });

});

var Scrolled = {
    init: function () {
        var that = this;

        that.scrollableContainer();
    },

    scrollableContainer: function () {
        $('[class^=scrollableContainer]').on('scroll', function () {
            var $this = $(this);
            var scrollPos = $this.scrollLeft();
            var width = $this.width();
            var scrollWidth = $this.get(0).scrollWidth;
            var container = $this.closest('[class^=scrollableContainerShadow]');

            if (scrollPos === 0) {
                container.removeClass('left');
            } else {
                container.addClass('left');
            }

            if ((scrollPos + width) === scrollWidth) {
                container.removeClass('right');
            } else {
                container.addClass('right');
            }
        });
    }
}

// Side Nav Start
var FloatingSubNav = {
    isMobile: false,
    activeSubNavIndex: 1,
    magicLine: '#magic-line',
    init: function (windowScroll) {

        this.addMagicLine('.subnavgroup');

        // Check if will desktop or not then if desktop apply the floating scroll function
        if (FloatingSubNav.checkIfNotMobile() === false) {
            FloatingSubNav.checkScrollPos(windowScroll);
            $('.subnav-scroll').removeClass('d-none');
            FloatingSubNav.checkScrollableActiveSection(windowScroll);
        } else {
            $('.subnav-scroll').removeClass('d-none');
            FloatingSubNav.positionToRelative('.subnav-scroll');
        }

        FloatingSubNav.bindEvents();

    },

    bindEvents: function () {
        var that = this;

        $('.subnavgroup li a').on('click', function () {
            var sectionToScroll = '#' + $(this).parent().attr('data-section');
            if (typeof scrollOmnitureBegin === 'function') {
                scrollOmnitureBegin();
            }
            that.animateToSection(sectionToScroll);
        });
    },

    addMagicLine: function (element) {
        $(element).append("<li class='listStyleNone' id='magic-line'></li>");

    },

    checkScrollPos: function (scrollPos) {
        // Define variables
        var spaceBefore = 45; // space before scrollable area
      
        //var spaceAfter = 50; // space after scrollable area
        var scrollableArea = '.scrollable-area';
        var elementToPositon = '.subnav-scroll';
       
        //var endPosElement = 'footer';
        var totalSpacesBeforeScrollableArea = this.getScrollableAreaTopValue(scrollableArea, spaceBefore);
        console.log(totalSpacesBeforeScrollableArea);

        // pass scrollable area element instead of always looking for the footer to support cases wherein there's content between the scrollable area and the footer
        // we don't need the hardcoded spaceAfter value anymore
        if (scrollPos >= totalSpacesBeforeScrollableArea && scrollPos < this.getScrollableAreaEndValue(elementToPositon, scrollableArea, spaceBefore)) {
            this.positionToFix(elementToPositon, spaceBefore, $('.subnav-scroll').width());
        } else if (scrollPos >= this.getScrollableAreaEndValue(elementToPositon, scrollableArea, spaceBefore)) {
            this.positionToAbsolute(elementToPositon);
        } else {
            this.positionToRelative(elementToPositon);
        }

    },

    checkScrollableActiveSection: function (scrollPos) {
        var that = this;
        var scrollableContents = '.scrollable-contents';
        var subNav = '.subnav-scroll';
        var scrollableContentsLength = $(scrollableContents).find('> div').length;
        var currentIndex = 1;
        scrollPos = Math.ceil(scrollPos);

        //if (scrollPos === $(window).height()) {
        if ($(window).scrollTop() + $(window).height() === $(document).height()) {
            currentIndex = scrollableContentsLength;
        } else {
            for (var i = 1; i < scrollableContentsLength + 1; i++) {
                if (i === 1) {
                    if (scrollPos < FloatingSubNav.getSectionTopValue(scrollableContents, 1)) {
                        currentIndex = 1;
                        break;
                    }
                } else if (scrollPos >= FloatingSubNav.getSectionTopValue(scrollableContents, i - 1) && scrollPos < FloatingSubNav.getSectionTopValue(scrollableContents, i)) {
                    currentIndex = i;
                    break;
                } else if (scrollPos >= FloatingSubNav.getSectionTopValue(scrollableContents, scrollableContentsLength)) {
                    currentIndex = scrollableContentsLength;
                    break;
                }
            }
        }
        this.activeSubNavIndex = currentIndex;
        this.checkActiveSubNav(this.activeSubNavIndex, subNav);
    },

    getSectionTopValue: function (scrollableSection, ctr) {
        /*var addedViewSpace = 150;
        if ($(scrollableSection).length > 0) {
            return $(scrollableSection).find("#scrollable-content-" + ctr).offset().top + addedViewSpace;
        }*/

        var scrollables = $(scrollableSection), scrollable;
        if (scrollables.length > 0) {
            scrollable = scrollables.find("#scrollable-content-" + ctr);
            return Math.floor(scrollable.offset().top + scrollable.height());
        }
    },

    checkActiveSubNav: function (activeIndex, subNav) {
        $(subNav).find('.subnavgroup li').removeClass('subnav_active');
        $(subNav).find('.subnavgroup li:nth-child(' + activeIndex + ')').addClass('subnav_active');
        if (typeof scrollOmniture === 'function') {
            scrollOmniture($(subNav).find('.subnavgroup li:nth-child(' + activeIndex + ')'), activeIndex);
        }
        this.animateMagicLine(activeIndex, subNav);
    },

    animateMagicLine: function (activeIndex, subNav) {
        var that = this;
        if ($(subNav).length > 0) {
            var target = $(subNav).find('.subnavgroup li:nth-child(' + activeIndex + ') a');
            var topPos = target.position().top;
            var newHeight = target.parent().height();
        }

        $(that.magicLine).stop().animate({
            top: topPos,
            height: newHeight
        });
    },

    animateToSection: function (sectionToScroll) {
        var topPos = $(sectionToScroll).offset().top;

        $('html, body').animate(
            {
                scrollTop: topPos
            },
            500,
            'linear',
            this.animateCallback
        );
    },

    animateCallback: function () {
        if (typeof scrollOmnitureEnd === 'function') {
            scrollOmnitureEnd();
        }
    },

    checkIfNotMobile: function () {

        var windowWidth = $(window).outerWidth();

        windowWidth > 767 ? isMobile = false : isMobile = true;

        return isMobile;
    },

    getScrollableAreaTopValue: function (scrollableArea, spaceBefore) {
        if ($(scrollableArea).length > 0) {
            return $(scrollableArea).position().top + spaceBefore;
        }

    },

    // ScrollableAreaEl compute height
    getScrollableAreaEndValue: function (subNavHeight, scrollableArea, spaceBefore) {
        var scrollableAreaEl = $(scrollableArea);

        return (scrollableAreaEl.outerHeight() + scrollableAreaEl.position().top) - ($(subNavHeight).innerHeight() + spaceBefore);
    },

    positionToFix: function (element, spaceBefore, width) {
        $(element).css({
            'position': 'fixed',
            'top': spaceBefore,
            'bottom': 'auto',
            'max-width': width + 'px'
        });
    },

    positionToRelative: function (element) {
        $(element).css({
            'position': 'relative',
            'top': 'auto',
            'bottom': 'auto',
            'max-width': ''
        });
    },

    positionToAbsolute: function (element) {
        $(element).css({
            'position': 'absolute',
            'top': 'auto',
            'bottom': 0
        });
    }
};


$(window).on('scroll', function () {
    checkScrollLocation();
    //hiding social floats on footer
}).on('resize', function () {
    var subNavScrollEl = $('.subnav-scroll');

    // need to recalculate on resize especially for magic line
    checkScrollLocation();
    // match subnavscroll width with its parent using js since position:fixed ignores the parent width
    subNavScrollEl.width(subNavScrollEl.parent().width());
});

$(document).ready(function () {
    Scrolled.init();
    // FocusUntrapper();

    // call scrollable-area FloatingSubNav
    var windowScroll = document.documentElement.scrollTop;

    if ($('.scrollable-area').length > 0) {
        FloatingSubNav.init(windowScroll);
    }
    //FocusUntrapper();

    // Page loader trigger
    $("#show-loader-contained-mask").click(function () {
        // start showing the loader
        showLoaderWithMask('#brf-loader-contained-mask');
    });

    clickDragScroll_table();
    
});
;

//reset the scrollable container location
function checkScrollLocation() {
    if ($('.scrollable-area').length > 0) {
        var windowScroll = window.pageYOffset || document.documentElement.scrollTop;

        // Check if will desktop or not then if desktop apply the floating scroll function
        if (FloatingSubNav.checkIfNotMobile() === false) {
            FloatingSubNav.checkScrollPos(windowScroll);
            FloatingSubNav.checkScrollableActiveSection(windowScroll);
        } else {
            FloatingSubNav.positionToRelative('.subnav-scroll');
        }
    }
}

// Side Nav end

// Click and Drag Scroll Funtions
function clickDragScroll_table() {
    const slider = document.querySelectorAll('.clickdragscroll');
    const sliderCount = slider.length;

    if (sliderCount > 0) {
        let isDown = false;
        let startX;
        let scrollLeft;

        // loop all .clickdragscroll classname
        for (let x = 0; x < sliderCount; x++) {
            let s = slider[x];
            s.addEventListener('mousedown', function (e) {
                isDown = true;
                s.classList.add('active');
                startX = e.pageX - s.offsetLeft;
                scrollLeft = s.scrollLeft;
            });
            s.addEventListener('mouseleave', function () {
                isDown = false;
                s.classList.remove('active');
            });
            s.addEventListener('mouseup', function () {
                isDown = false;
                s.classList.remove('active');
            });
            s.addEventListener('mousemove', function (e) {
                if (!isDown) return;
                e.preventDefault();
                const x = e.pageX - s.offsetLeft;
                const walk = (x - startX) * 3; //scroll-fast
                s.scrollLeft = scrollLeft - walk;
            });
        }
    }
}