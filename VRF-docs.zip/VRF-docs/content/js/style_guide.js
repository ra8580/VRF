$(function() {
    //initializer for the icons loader 
    iconRunner.loadTheIconsInit();
});

const iconRunner = {
    //global val
    _sideListTargetClass: '.lstg_projIconsList',
    _targetDOMIconListClass: '.olListIcons',
    _tb_id_searchbox: '#search_icons',

    //store all cssstyle Rules with key of button id
    __stylesList: new Map(),
    __searchedKey: '',

    //init function for the icon loader
    loadTheIconsInit: function () {
        //read the link stylesheets attached to the [page]
        //// read the icon file added to page and populate the icons from it 
        var cssIconresult = this.readAttachedStylesheets();
        //console.log("cssIconresult");
        //console.log(cssIconresult);

        if (cssIconresult.length > 0) { 
            this.addProjectNamesToSideBar(cssIconresult, this._sideListTargetClass, this._targetDOMIconListClass);

            $("#btn_0").click();

            this.initSearch(this._tb_id_searchbox);
        } else {
            $(this._sideListTargetClass).css("color", "red").text("Please add css file link in HTML head");
            $(".loadingContainer").toggle();
        }
    },
    //read the attached stylesheet from the page and populate the list
    readAttachedStylesheets: function () {
        //array storing the file names for the icons
        const iconsFilesInDom = [];

        var headContent = $("head").children();
        //console.log(headContent);  
        if (headContent) {
            for (var _i = 0; _i < headContent.length; _i++) {
                var ele = headContent[_i];
                if (ele.nodeName === "LINK") {
                    // get icon file added by link other wise comment this out 
                    if (("" + ele.href).indexOf('-icons.css') >= 0 || ("" + ele.href).indexOf('-icon.css') >= 0) {
                        //console.log(ele);
                        const path_arr = ele.href.split('/');
                        //console.log(document.styleSheets);
                        //console.log(ele.rules);   
                        //console.log(path_arr[path_arr.length - 1]);

                        //console.log("disabling the css");
                        //disable the stylesheet from page e.g. bce-icons.css
                        //$('link[href$="' + path_arr[path_arr.length - 1] + '"]').prop('disabled', true); 
                         
                        var $ele = $(ele)[0]; 
                        //check for data-cname attribute that indicate the classname of the new set of icons
                        var iconname = ele.dataset.cname;
                       
                        //for IE and Chrome
                        if ($ele.sheet) { 
                            iconsFilesInDom.push({
                                name: path_arr[path_arr.indexOf("Dev") + 1], fpath: path_arr[path_arr.length - 1],
                                size: $ele.sheet.rules.length, styleRules: $ele.sheet.rules, cname: iconname
                            });
                        }
                        else {
                            //FIREFOX IF SHEET IS NULL
                            for (var _j = 0; _j < (headContent.length - 1); _j++) {
                                var targetElem = headContent[_j].nextElementSibling;
                                var targetElemSheet = headContent[_j].nextElementSibling.sheet;
                                if (targetElem.nodeName === "LINK") {
                                    // get icon file added by link other wise comment this out 
                                    if (("" + targetElem.href).indexOf('-icons.css') >= 0 || ("" + targetElem.href).indexOf('-icon.css') >= 0) {
                                        const path_array = targetElem.href.split('/'); 
                                        //console.log(document.styleSheets);
                                        //disable the stylesheet from page e.g. bce-icons.css
                                        //$('link[href$="' + path_array[path_array.length - 1] + '"]').prop('disabled', true);

                                        if (targetElemSheet) {
                                            iconsFilesInDom.push({
                                                name: path_array[path_array.indexOf("Dev") + 1], fpath: path_array[path_array.length - 1],
                                                size: targetElemSheet.rules.length, styleRules: targetElemSheet.rules, cname: iconname
                                            });
                                        } 
                                    }
                                }
                            }

                            break;
                        }

                        
                    }
                }
            }
        }

        return iconsFilesInDom;
    },

    //funcation to add project names to the list
    addProjectNamesToSideBar: function (iconsFilesInDom, _sideListTargetClass, _iconTargetListClassName) {
        //if there any icon files attached iterate through them
        if (iconsFilesInDom.length > 0) {
            let _index = 0;
            for (var i = 0; i < iconsFilesInDom.length; i++) {
                var list = iconsFilesInDom[i];
                var _item_btn = document.createElement('button');
                var _val_btn_id = 'btn_' + _index;
                _item_btn.id = _val_btn_id;
                _item_btn.classList.add("list-group-item", "list-group-item-action", "d-flex", "justify-content-between", "align-items-center");
                _item_btn.textContent = list.name;
                
                _item_btn.setAttribute('data-target-icon-list', _iconTargetListClassName);
                _item_btn.setAttribute('data-fPath', list.fpath);
                //create data-cname attribute if declared in the css reference using data-cname attribute
                if (list.cname != undefined) {
                    _item_btn.setAttribute('data-cname', list.cname);
                }
                //create data-shopname attribute for SHOP LOB icon names
                //if (list.shopname != undefined) {
                //    _item_btn.textContent = `${list.name}-${list.shopname}`;
                //}

                //_item_btn.onclick = function() { loadSelectedIconsOnPage( _val_btn_id); };

                var _item_span_size = document.createElement("span");
                _item_span_size.classList.add("badge");
                _item_span_size.classList.add("badge-primary");
                _item_span_size.classList.add("badge-pill");
                _item_span_size.textContent = list.size;
                _item_btn.appendChild(_item_span_size);


                //console.log("_item_btn_txt"); 
                var _item_btn_txt = (_item_btn.outerHTML).replace(_val_btn_id + '"', _val_btn_id + '\" onClick="iconRunner.loadSelectedIconsOnPage(this.id)"');
                //console.log(_item_btn_txt); 

                $(_sideListTargetClass).append(_item_btn_txt);

                //add the cssRule list object to the stylelist to retrieve on click
                this.__stylesList.set(_val_btn_id, list.styleRules);

                _index++;
            }
        }
    },
    //trigger event on side bar button click to show only the selected file icons
    loadSelectedIconsOnPage: function (_btn_id) {
        //hide the preview bar first 
        this.showPreviewSideBar(false);

        //console.log("_btn_id " + _btn_id); 
        const $_btn_id_query = $("#" + _btn_id);

        var filename = $_btn_id_query.attr("data-fpath");

        $('link[href*="-icons.css"]').prop('disabled', true);
        $('link[href$="' + filename + '"]').prop('disabled', false);
        //console.log("Icon css enabled");

        if (!$_btn_id_query.hasClass('active')) {
            $('.active').not($_btn_id_query).removeClass('active');
            $_btn_id_query.toggleClass('active');
        }

        //pass the class name to be use for the icon if declared 
        var cname = $_btn_id_query.attr("data-cname");

        //console.log(__stylesList); 
        if (this.__stylesList.has(_btn_id)) {
            //console.log("Found the styles for the selected");
            //console.log(__stylesList.get(_btn_id));  
            $(".loadingContainer").toggle();
            this.fxIconLoaderFromList(this.__stylesList.get(_btn_id), $_btn_id_query.attr("data-target-icon-list"), 
                cname);

            $(".loadingContainer").toggle();

            //trigger search filter if the search text is already there
            if (this.__searchedKey.length > 0) {
                this.filterTheIconList(this.__searchedKey);
            }
        }
    },

    loadIconsCssFromList: function (cssRuleList) {
        const _cssRulesClassStringList = [];
        //console.log("cssRuleList");
        //console.log(cssRuleList);
        //iterate over the cssRule list
        for (var i = 0; i < cssRuleList.length; i++) {
            const iconClasses = cssRuleList[i];
            //console.log("iconClasses");
            //console.log(cssRuleList.length);
            //console.log(iconClasses);
            // filtering only css styles
            //for chrome and new browsers
            if ("" + iconClasses.__proto__.constructor.name === 'CSSStyleRule') {
                // check for the lement which may contain after or before colons
                const iconselectortext = iconClasses.selectorText;
                if (iconselectortext.indexOf('::') >= 0) {
                    //console.log(iconClasses.style);
                    //console.log(iconselectortext);  

                    //check if the cssStyleDeclaration contains "content"
                    if ($.inArray("content", iconClasses.style) !== -1) {
                        _cssRulesClassStringList.push(iconselectortext);
                    }
                    //check if the  cssStyleDeclaration contains "transform"
                    else if ($.inArray("transform", iconClasses.style) !== -1) {
                        _cssRulesClassStringList.push(iconselectortext);
                    }
                }
            }
            //for iE 
            else if (iconClasses.selectorText) {
                //console.log("IE ");
                if (iconClasses.selectorText.indexOf("::") >= 0) {
                    const iconselectortext = iconClasses.selectorText;

                    //check if the cssStyleDeclaration contains "content"
                    if ($.inArray("content", iconClasses.style) !== -1) {
                        _cssRulesClassStringList.push(iconselectortext);
                    }
                    //check if the  cssStyleDeclaration contains "transform"
                    else if ($.inArray("transform", iconClasses.style) !== -1) {
                        _cssRulesClassStringList.push(iconselectortext);
                    }
                }
            }
        }
        //console.log("_cssRulesClassStringList");
        //console.log(_cssRulesClassStringList);
        return _cssRulesClassStringList;
    },

    //function to be called on on click if the  button has styles in it
    fxIconLoaderFromList: function (_listOfClasses, _targetIconDOMListClass, cname) {
        var cssStyleList = this.loadIconsCssFromList(_listOfClasses);
        //console.log(cssStyleList); 
        if (cssStyleList.length > 0) {

            const cleanCssNamesArr = [];
            //filter for classes contain font family declaration as icons donot have them individually  
            for (var i = 0; i < cssStyleList.length; i++) {
                const iconcontent = cssStyleList[i];

                //console.log(_targetIconDOMListClass);
                //const _targetDOMListClass = '.olListIcons';
                const cssclassNameClean = this.buildclassNamesFromRules(iconcontent);
                cleanCssNamesArr.push.apply(cleanCssNamesArr, cssclassNameClean);
                //console.log(cssclassNameClean);
            }
            //console.log("cleanCssNamesArr");
            //console.log(cleanCssNamesArr);
            const _iconLoadedSuccess = this.loadIconsClassesFromArr(cleanCssNamesArr, _targetIconDOMListClass, cname);
            //console.log( _iconLoadedSuccess); 
        }
    },

    // get the class name for icons
    buildclassNamesFromRules: function (iconSelectorText) {
        const iconClassName = [];
        //check if there are multiple class declarations
        if (iconSelectorText.indexOf(",") >= 0) {
            const iconMultipleClasses = iconSelectorText.split(',');
            // Loop for multiple classes
            for (var i = 0; i < iconMultipleClasses.length; i++) {
                const singleIconClassText = iconMultipleClasses[i];
                iconClassName.push(this.getIconClassNameFromRule(singleIconClassText.trim()));
            }
        } else {
            //for single class declaration get the icon class name
            iconClassName.push(this.getIconClassNameFromRule(iconSelectorText));
            //console.log(getIconClassNameFromRule(iconSelectorText));  
        }
        return iconClassName;
    },
    //split the icon css rule to remove ::before
    getIconClassNameFromRule: function (_iconClassName) {
        if (_iconClassName.indexOf("::") >= 0) {
            const iconnameArr = _iconClassName.split('::');
            return iconnameArr[0].replace('.', '');
        }
        return _iconClassName;
    },
    //add icon class names to the DOM container
    loadIconsClassesFromArr: function (_cleanCssNamesArr, _targetDOMListClass, cname){
        //console.log(_cleanCssNamesArr); 
        //console.log(_targetDOMListClass); 
        $(_targetDOMListClass).empty();

        for (let i = 0; i < _cleanCssNamesArr.length; i++) {
            //create the list item
            //Promise.resolve()
            //    .then(function() {
            //        // update the DOM
            //        setTimeout(function() {
            const elemCreatedToAdd = this.createListItemFromClassName(_cleanCssNamesArr[i], cname);


            //console.log("elemCreatedToAdd");
            //console.log(elemCreatedToAdd); 

            if (elemCreatedToAdd !== null)
                $(_targetDOMListClass).append(elemCreatedToAdd);
            //    }, 0); 
            //});
        }

        //disableLoader
        //$(".cssload-dots").toggle();
        return false;
    },


    // add icon content to the list
    createListItemFromClassName: function (_cssClassName, cname) {
        //set class name to be use if declare else use default icon
        var firstclassname = cname != undefined ? cname : "icon"
        var _item_btn = document.createElement('div');
        _item_btn.tabIndex = 0;
        _item_btn.classList.add("iconListItem");
        _item_btn.classList.add("card");
        _item_btn.classList.add("pad-20");
        _item_btn.classList.add("txtSize30");
        _item_btn.onclick = function () { iconRunner.loadIconPreview(this); };
        _item_btn.addEventListener("keydown", function (event) {
            //if (event.key === "Enter") {  
            iconRunner.loadIconPreview(this);
            //}
        });

        var _item_span_first = document.createElement("span");
        var _item_div_cname = document.createElement("div")

        //check if multi icon
        if (_cssClassName.indexOf(" ") > 0) {

            const iconnameArr = _cssClassName.split(' ');

            const iconParent = iconnameArr[0].replace('.', '');
            const multiPath = iconnameArr[1].replace('.', '');

            //first check if icon parent exist
            if ($("." + iconParent).length > 0) {
                //if yes
                //change the button to null so not adding any new button
                _item_btn = null;
                //then add the icon to that parent in DOM  
                //_item_span_first.classList.add("icon");
                _item_span_first.classList.add(firstclassname);
                _item_span_first.classList.add(multiPath);
                _item_div_cname.classList.add("small-text", "pad-t-10");
                _item_div_cname.textContent = _cssClassName;

                $("." + iconParent).append(_item_span_first);
                $("." + iconParent).append(_item_div_cname);
                

            } else {
                //if not then create a span 
                //_item_span_first.classList.add("icon");
                _item_span_first.classList.add(firstclassname);
                _item_span_first.classList.add(iconParent);
                _item_div_cname.classList.add("small-text", "pad-t-10");
                _item_div_cname.textContent = _cssClassName;

                var _item_span_multi_child = document.createElement("span");
                _item_span_multi_child.classList.add(cname);
                _item_span_multi_child.classList.add(multiPath);

                _item_span_first.appendChild(_item_span_multi_child);

                //change color of multiIcon
                _item_btn.classList.add("multiSpecialsIcon");

                _item_btn.appendChild(_item_span_first);
                _item_btn.appendChild(_item_div_cname);
            }
        } else {
            //_item_span_first.classList.add("icon");
            _item_span_first.classList.add(firstclassname);
            _item_span_first.classList.add(_cssClassName);
            _item_div_cname.classList.add("small-text", "pad-t-10");
            _item_div_cname.textContent = _cssClassName;


            // console.log(_item_span_first);
            _item_btn.appendChild(_item_span_first);
            _item_btn.appendChild(_item_div_cname);

        }

        return _item_btn; 
    },


    loadIconPreview: function (btnElem) {
        this.showPreviewSideBar(true);
        //console.log("key presed load icon preview" );  
        //console.log($('#cb_showCanvasGrid').prop('checked'));   
        // this.createCanvasForPreview($('#cb_showCanvasGrid').prop('checked'));
        // this.putIconToCanvas(btnElem);
    },

    showPreviewSideBar: function (_showit) {
        const $sideBar_previewCont = $(".stickyPreviewContents");
        const $id_main_content_pane = $('#main_preview_pane');
        // if (_showit) {
        //     $id_main_content_pane.removeClass("col-xl-10 col-lg-10 col-md-9 col-sm-9");
        //     $id_main_content_pane.addClass("col-xl-8 col-lg-8 col-md-7 col-sm-7");
        //     $sideBar_previewCont.show('fast');
        // } else {
        //     $id_main_content_pane.removeClass("col-xl-8 col-lg-8 col-md-7 col-sm-7");
        //     $id_main_content_pane.addClass("col-xl-10 col-lg-10 col-md-9 col-sm-9");
        //     $sideBar_previewCont.hide('fast');
        // }
    },


    // createCanvasForPreview: function (_showCanvasGrid){
    //     //make it a square
    //     var cw = $('.cv_icon_digo').width();
    //     $('.cv_icon_digo').css({ 'height': cw + 'px' });

    //     var canvas = document.getElementById('cv_icon_digo');

    //     //Always check for properties and methods, to make sure your code doesn't break in other browsers.
    //     if (canvas.getContext) {
    //         var ctx = canvas.getContext("2d");

    //         ctx.clearRect(0, 0, canvas.width, canvas.height);

    //         if (_showCanvasGrid) {
    //             ctx.fillStyle = "transparent";
    //             ctx.setLineDash([10, 10]);
    //             ctx.lineWidth = 1;
    //             ctx.strokeStyle = "#787878";
    //             //horizontal lines
    //             for (i = 50; i <= 100; i += 50) {
    //                 ctx.moveTo(0, i);
    //                 ctx.lineTo(canvas.width, i);
    //                 ctx.stroke();
    //             }
    //             //vertical lines
    //             //for (i = 100; i <= 200; i += 100) {
    //             //    ctx.moveTo(i, 0);
    //             //    ctx.lineTo(i, canvas.width / 2);
    //             //    ctx.stroke();
    //             //}

    //             //intersection lines
    //             ctx.moveTo(0, canvas.height / 2);
    //             ctx.lineTo(canvas.width, canvas.height / 2);
    //             ctx.stroke();
    //             ctx.moveTo(150, 0);
    //             ctx.lineTo(150, canvas.width);
    //             ctx.stroke();
    //         } else {
    //             ctx.clearRect(0, 0, canvas.width, canvas.height);
    //         }
    //     }
    // },

    // putIconToCanvas: function (elemBtn){
    //     $('.iconPreviewContent').css({ 'height': $('.cv_icon_digo').height() + 'px' });
    //     $('.iconPreviewContent').css({ 'width': $('.cv_icon_digo').width() + 'px' });

    //     //console.log($(elemBtn)); 
    //     var _itemcontent = $(elemBtn).html();
    //     $(".iconPreviewContent").html(_itemcontent);
    //     //console.log($(_itemcontent).attr("class"));


    //     var _iconClasses = $(_itemcontent).attr("class");
    //     _iconClasses = _iconClasses.replace("icon ", "");
    //     $("._selected_iconLabel").html(_iconClasses);
    //     //resizing icon for fit in canvas
    //     //$('.iconPreviewContent span.icon').css('font-size', '1em');

    //     //console.log("checking"); 
    //     while ($('.iconPreviewContent span.icon').width() > $('.iconPreviewContent').width()) {
    //         //console.log("checking");
    //         $('.iconPreviewContent span.icon').css('font-size', (parseInt($('.iconPreviewContent span.icon').css('font-size')) - 1) + "px");
    //     }
    // },

    //function to filter the icon list based on the keywords
    initSearch: function (_searchTextId) {
        //search filter for icons
        const $_searchtextInput = $(_searchTextId);
        $_searchtextInput.on("keyup", function () {
            var value = $_searchtextInput.val().toLowerCase();
            //setting the searched key globally
            iconRunner.__searchedKey = value;
            iconRunner.filterTheIconList(value);
            iconRunner.checkIfSearchIsActive($_searchtextInput);
        });
    },

    //highlight if the search is still active
    checkIfSearchIsActive: function ($_searchtextInput) {
        if (!$_searchtextInput.val()) {
            if ($_searchtextInput.hasClass('search_active')) {
                $_searchtextInput.removeClass('search_active');
            }
            if (!$(".clearsearch_container").hasClass('hidden')) {
                $(".clearsearch_container").addClass('hidden');
            }
        } else {
            if (!$_searchtextInput.hasClass('search_active')) {
                $_searchtextInput.addClass('search_active');
            }
            if ($(".clearsearch_container").hasClass('hidden')) {
                $(".clearsearch_container").removeClass('hidden');
            }
        }
    },

    filterTheIconList: function (_searchedValue) {
        $(".olListIcons  .iconListItem ").filter(function () {
            var span_class_name = $(this).children().attr("class").replace("icon ", "");
            $(this).toggle(span_class_name.toLowerCase().indexOf(_searchedValue) > -1);
        });
    }


};
 

// check box event listener for show grid
// $('#cb_showCanvasGrid').click(function() { 
//    //console.log(this.checked);
//     iconRunner.createCanvasForPreview(this.checked);
// });

 
//clear the content of search
$('#clear_search_icons').click(function() {
    //reset the values
    $("#search_icons").val('');
    iconRunner.__searchedKey = "";

    //reload the list
    $(".lstg_projIconsList .active").click();

    if (!$(".clearsearch_container").hasClass('hidden')) {
        $(".clearsearch_container").addClass('hidden');
    } 
});