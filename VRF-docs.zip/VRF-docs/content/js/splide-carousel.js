/*!
 * splide-carousel.js
 * Last Modified  : October 12, 2023
 * Note: Use plain/vanilla JavaScript (no jQuery) to make scripts easy to migrate to ReactJS widgets if necessary
 */

(function (factory) {
	typeof define === 'function' && define.amd ? define(factory) : factory();
})(function () {
	'use strict';

	// START shared constants

	var KEYS = {
		LEFT: 37,
		UP: 38,
		RIGHT: 39,
		DOWN: 40
	};
	var BREAKPOINTS = {
		"MOBILE": {
			"SYMBOL": "m",
			"MAX": 767.98
		},
		"TABLET": {
			"SYMBOL": "t",
			"MIN": 768,
			"MAX": 991.98
		},
		"DESKTOP": {
			"SYMBOL": "d",
			"MIN": 992
		}
	};
	var DEFAULT_LABELS_EN = {
		labelCarousel: 'featured contents',
		labelCarouselRoleDesc: 'carousel',
		labelSlideRoleDesc: 'slide',
		labelSlidePrefix: 'featured content',
		labelTo: 'to',
		labelPrevious: 'view previous slide of carousel',
		labelNext: 'view next slide of carousel',
		labelDotNavigationGroup: 'carousel navigation',
		labelDotNavigationPrefix: 'featured content slide',
		labelDotNavigationPrefixPlural: 'featured content slides',
		labelCurrent: 'current'
	};
	var DEFAULT_LABELS_FR = {
		labelCarousel: 'contenus en vedette',
		labelCarouselRoleDesc: 'carrousel',
		labelSlideRoleDesc: 'panneau',
		labelSlidePrefix: 'contenu en vedette',
        labelTo: 'à',
        labelPrevious: 'Afficher le panneau précédent du carrousel',
		labelNext: 'Afficher le panneau suivant du carrousel',
		labelDotNavigationGroup: 'navigation du carrousel',
		labelDotNavigationPrefix: 'contenu en vedette panneau',
		labelDotNavigationPrefixPlural: 'contenu en vedette panneaux',
		labelCurrent: 'en cours'
	};
	var SELECTOR_CAROUSEL_OUTER_CONTAINER = '.js-carousel-outer-container';
	var CUSTOM_SPLIDE_MOUNTED_EVENT = 'splideMounted';
	var CUSTOM_AFTER_PAGINATION_UPDATE_EVENT ='pagination-later-update';

	// END shared constants



	// START generic utility functions

	function getIsFrench() {
		var language = document.documentElement.lang;

		if (language === undefined) {
			return false;
		}

		return language.substring(0, 2).toLowerCase() === 'fr';
	}

	function getScreenSizeSymbol() {
		if (window.matchMedia('(min-width: ' + BREAKPOINTS.DESKTOP.MIN + 'px)').matches) {
			return BREAKPOINTS.DESKTOP.SYMBOL;
		} else if (window.matchMedia('(min-width: ' + BREAKPOINTS.TABLET.MIN + 'px)').matches) {
			return BREAKPOINTS.TABLET.SYMBOL;
		} else {
			return BREAKPOINTS.MOBILE.SYMBOL;
		}
	}

	function closest(el, selector) {
		var closestAncestor = el,
			matchFound = false;

		if (typeof el.closest === 'function') {
			return el.closest(selector);
		}

		do {
			if (closestAncestor.matches(selector)) {
				matchFound = true;
				break;
			}

			closestAncestor = closestAncestor.parentNode;
		} while (closestAncestor && closestAncestor.nodeType === 1);

		return matchFound ? closestAncestor : undefined;
	}

	function extendShallow() {
		for (var i = 1; i < arguments.length; i++)
			for (var key in arguments[i])
				if (arguments[i].hasOwnProperty(key))
					arguments[0][key] = arguments[i][key];
		return arguments[0];
	}

	// END generic utility functions



	// START carousel-specific scripts

	function CustomCarousel(splideInstance, Components2, options) {
		var isFrench = getIsFrench(),
			currentScreenSizeSymbol = getScreenSizeSymbol(),
			prevScreenSizeSymbol,
			carousel = Components2.Elements.root,
			carouselOuterContainer = closest(carousel, SELECTOR_CAROUSEL_OUTER_CONTAINER),
			track = Components2.Elements.track,
			list = Components2.Elements.list,
			slides = list.querySelectorAll('.splide__slide'),
			windowResizeTimeOut,
			strDataCarouselLabels = carousel.dataset.carouselLabels,
			dataCarouselLabels = strDataCarouselLabels ? JSON.parse(strDataCarouselLabels) : {},
			defaultLabels = isFrench ? DEFAULT_LABELS_FR : DEFAULT_LABELS_EN,
			labels = extendShallow({}, defaultLabels, dataCarouselLabels),
			hasFrozenSlide = false;

		function mount() {
			bindEventListeners();
			bindOtherEventListeners();

			carousel.dispatchEvent(new CustomEvent(CUSTOM_SPLIDE_MOUNTED_EVENT, {
				detail: {
					splideInstance: splideInstance
				}
			}));
		}

		function bindEventListeners() {
			splideInstance.on('ready', function () {
				var i,
					len = slides.length;

				if (len === 0) {
					return;
				}

				for (i = 0; i < len; i++) {
					slides[i].setAttribute('role', 'group');
				}

				// must manually trigger resize because some browsers don't automatically do it upon initial loading
				onLoadOrResize(true);
			}).on('moved', function () {
				setTimeout(function () {
					var pages = carousel.querySelectorAll('.splide__pagination__page'),
						page,
						i,
						len = pages.length,
						firstVisibleSlide;

					for (i = 0; i < len; i++) {
						page = pages[i];
						page.removeAttribute('tabindex');
						page.removeAttribute('aria-selected');
						updatePaginationLabel(page, i, len);
					}

                    if (len > 0) {
                        document.dispatchEvent(new CustomEvent(CUSTOM_AFTER_PAGINATION_UPDATE_EVENT));
                    }

					updatePrevNextButtonLabels();
				}, 200);
			});
		}

		function bindOtherEventListeners() {

			carousel.addEventListener('click', function (event) {
				var target = event.target;

				if (target.matches('.splide__arrow--prev, .splide__arrow--next')) {
					track.setAttribute('aria-live', 'polite');
				}
			});

			carousel.addEventListener('focusout', function (event) {
				var target = event.target;

				if (target.matches('.splide__arrow--prev, .splide__arrow--next')) {
					setTimeout(function () {
						track.setAttribute('aria-live', 'off');
					}, 500);
				}
			});

			// splide's resize sometimes unnecessarily fires multiple times so listen to window resize instead
			window.addEventListener('resize', onLoadOrResize);
		}

		function triggerSameHeight() {
			var sameHeightElements = slides[0].querySelectorAll('.same-height'),
				i,
				len;

			track.setAttribute('aria-live', 'off');

			for (i = 0, len = sameHeightElements.length; i < len; i++) {
				sameHeightElements[i].dispatchEvent(new Event('resize'));
			}
		}

		function onLoadOrResize(isInit) {
			clearTimeout(windowResizeTimeOut);

			windowResizeTimeOut = setTimeout(function () {
				currentScreenSizeSymbol = getScreenSizeSymbol();

				if (prevScreenSizeSymbol !== currentScreenSizeSymbol) {
					updateCarouselInteractivity();
					updateCarouselRolesAndLabels();
					triggerSameHeight();
					prevScreenSizeSymbol = currentScreenSizeSymbol;
				}

				updateCarouselControlsRolesAndLabels();
			}, 200);
		}

		function updateCarouselRolesAndLabels() {
			var prePhrase = hasFrozenSlide ? labels.labelOtherCard : labels.labelCard,
				allSlides = (hasFrozenSlide ? carouselOuterContainer : carousel).querySelectorAll('.splide__slide'),
				allSlidesCount = allSlides.length,
				nonFrozenSlidesCount = allSlidesCount - 1,
				i,
				len,
				slide,
				finalLabel,
				indexAmongAllSlides,
                indexAmongNonFrozenSlides,
                isCurrent;

			for (i = 0, len = slides.length; i < len; i++) {
				slide = slides[i];
				isCurrent = slide.classList.contains('js-is-current');
				indexAmongAllSlides = i + 1;
				indexAmongNonFrozenSlides = indexAmongAllSlides - 1;

				if (i === 0) {
					if (allSlidesCount === 1) {
						finalLabel = hasFrozenSlide || isCurrent ? labels.labelChosenCard : prePhrase;
					} else {
						if (hasFrozenSlide) {
							finalLabel = labels.labelChosenCard;
						} else {
							finalLabel = prePhrase + " " + indexAmongAllSlides + " " + labels.labelOf + " " + allSlidesCount + " " + labels.labelCurrentSelection;
						}
					}
				} else {
					if (hasFrozenSlide) {
						finalLabel = prePhrase + " " + indexAmongNonFrozenSlides + " " + labels.labelOf + " " + nonFrozenSlidesCount;
					} else {
						finalLabel = prePhrase + " " + indexAmongAllSlides + " " + labels.labelOf + " " + allSlidesCount;
					}
				}

				slide.setAttribute('aria-label', finalLabel);
				slide.setAttribute('role', 'group');
			}

			list.setAttribute('role', 'presentation');
			track.setAttribute('role', 'presentation');
		}

		function updateCarouselControlsRolesAndLabels() {
			updatePrevNextButtonLabels();
			updatePaginationLabels();
		}

		function updatePrevNextButtonLabels() {
			var nextButton = carousel.querySelector('.splide__arrow--next'),
				prevButton = carousel.querySelector('.splide__arrow--prev');

			if (nextButton) {
				nextButton.setAttribute('aria-label', labels.labelNextBtn);
			}

			if (prevButton) {
				prevButton.setAttribute('aria-label', labels.labelPrevBtn);
			}
		}

		function updatePaginationLabels() {
			var pagination,
				pages,
				page,
				i,
				len;

			pagination = carousel.querySelector('.splide__pagination');

			if (!pagination) {
				return;
			}

			pagination.setAttribute('role', 'group');
			pagination.setAttribute('aria-label', labels.labelCarouselNavigation);

			pages = carousel.querySelectorAll('.splide__pagination__page');

			for (i = 0, len = pages.length; i < len; i++) {
				page = pages[i];
				page.removeAttribute('tabindex');
				page.removeAttribute('aria-selected');
				page.removeAttribute('role');
				updatePaginationLabel(page, i);
			}
		}

		function updatePaginationLabel(element, index) {
			var isActive = element.classList.contains('is-active'),
				slideNo = index + 1,
				pageCount = Components2.Pagination.items.length,
				labelDefault = labels.labelDotNavigationPrefix + ' ' + slideNo + ' ' + labels.labelOf + ' ' + pageCount,
				labelCurrent = labelDefault + ' ' + labels.labelCurrent,
				label = isActive ? labelCurrent : labelDefault;

			element.setAttribute('aria-label', label);
		}

		function updateCarouselInteractivity() {
			var i,
				len;

			if (splideInstance.length <= options.perPage) {
				splideInstance.options = {
					drag: false,
					pagination: false
				};

				for (i = 0, len = slides.length; i < len; i++) {
					slides[i].removeAttribute('aria-roledescription');
				}

				carousel.removeAttribute('aria-roledescription');
			} else {
				splideInstance.options = {
					drag: true,
					pagination: true
				};

				for (i = 0, len = slides.length; i < len; i++) {
					slides[i].setAttribute('aria-roledescription', 'slide');
				}

				carousel.setAttribute('aria-roledescription', 'carousel');
			}
		}

		// END carousel-specific scripts

		return {
			mount: mount
		};
	}

	if (typeof window !== "undefined") {
		window.splide = window.splide || {};
		window.splide.Extensions = window.splide.Extensions || {};
		window.splide.Extensions.CustomCarousel = CustomCarousel;
	}

	// END carousel-specific scripts
});



var SELECTOR_CAROUSEL = '.splide:not(.is-initialized):not(.carousel-custom-init)';

function initCustomCarousel() {
	var carouselsToInit = document.querySelectorAll(SELECTOR_CAROUSEL),
		extensions = window.splide ? window.splide.Extensions : undefined,
		i,
		len = carouselsToInit.length,
		carouselToInit,
		splideInstance;

	for (i = 0; i < len; i++) {
		carouselToInit = carouselsToInit[i];
		splideInstance = new Splide(carouselToInit);
		splideInstance.mount(extensions);
	}
    
}


document.addEventListener('DOMContentLoaded', function () {
	setTimeout(initCustomCarousel, 0);
});