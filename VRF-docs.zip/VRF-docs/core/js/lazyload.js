/*!
 * lazyload.js
 * Last Modified  : 2023.9.15

 * Custom Lazyload Vanilla JS 
 * Note: Use plain/vanilla JavaScript (no jQuery) to make scripts easy to migrate to ReactJS widgets if necessary
*/

(function (factory) {
    typeof define === 'function' && define.amd ? define(factory) : factory();
})(function () {
    'use strict';
    
    let isInitialized = false;

    const handleLazyLoad = (element) => {
        if (element.tagName.toLowerCase() === 'img') {
            element.src = element.getAttribute('data-src');
            // set the 'srcset' attribute if exists
            if (element.hasAttribute('data-srcset')) {
                element.srcset = element.getAttribute('data-srcset');
            }
            element.classList.add('lazyloaded');
            element.classList.remove('lazyload');
        } else if (element.tagName.toLowerCase() === 'iframe') {
            element.src = element.getAttribute('data-src');
            element.classList.add('lazyloaded');
            element.classList.remove('lazyload');
        } else if (element.tagName.toLowerCase() === 'picture') {          
            // loop through child elements and apply data-src and data-srcset
            for (let child of element.children) {
                if (child.hasAttribute('data-src')) {
                    child.src = child.getAttribute('data-src');
                }
                if (child.hasAttribute('data-srcset')) {
                    child.srcset = child.getAttribute('data-srcset');
                }
            }
            // find the nested img tag and set its attributes
            const imgElement = element.querySelector('img');
            if (imgElement) {
                imgElement.src = imgElement.getAttribute('data-src');
                if (imgElement.hasAttribute('data-srcset')) {
                    imgElement.srcset = imgElement.getAttribute('data-srcset');
                }
            }
            // add 'lazyloaded' class to the picture element and the nested img element
            element.classList.add('lazyloaded');
            if (imgElement) {
                imgElement.classList.add('lazyloaded');
            }
          
            // Remove 'lazyload' class
            element.classList.remove('lazyload');
            if (imgElement) {
                imgElement.classList.remove('lazyload');
            }
        }
    };

    /*!
     * manual lazy loading function
     * if browser Intersection Observer
     * is not supported
     */
    const manualLazyLoad = (lazyItems) => {
        const handleScroll = () => {
            lazyItems.forEach((item) => {
                if (item.getBoundingClientRect().top <= window.innerHeight &&
                    item.getBoundingClientRect().bottom >= 0 &&
                    getComputedStyle(item).display !== 'none') {
                handleLazyLoad(item);
                }
            });
        };
        
        window.addEventListener('scroll', handleScroll);
        window.addEventListener('resize', handleScroll);
        window.addEventListener('orientationchange', handleScroll);
    };

    // initialize Intersection Observer
    const initIntersectionObserver = (lazyItems) => {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    handleLazyLoad(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        });
        
        lazyItems.forEach((item) => observer.observe(item));
    };

    // init lazyload
    const initLazyLoad = () => {
        let lazyItems = [].slice.call(document.querySelectorAll('.lazyload'));

        if (lazyItems.length === 0) {
            return;
        }
      
        if (isInitialized) {
            return;
        }
      
        if ('IntersectionObserver' in window) {
            initIntersectionObserver(lazyItems);
        } else {
            manualLazyLoad(lazyItems);
        }
      
        isInitialized = true;
    };
    
    // reset the initialization flag when new '.lazyload' elements are added
    const resetInitialization = () => {
        isInitialized = false;
        initLazyLoad();
    };
  
    // initialize using Mutation Observer
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.type === "childList") {
                resetInitialization();
            }
        });
    });
  
    const config = { attributes: true, childList: true, subtree: true };
    observer.observe(document.body, config);
  
    document.addEventListener('DOMContentLoaded', function() {
        initLazyLoad();
    });
  
    // expose globally if needed
    window.customLazyLoad = {
        init: initLazyLoad,
        reset: resetInitialization
    };

    /* Example for 
     * initialization using Event Delegation
     *
        document.addEventListener('click', function(event) {
            if (event.target.closest('.widget-container')) {
                resetInitialization();
            }
        });
    */
});